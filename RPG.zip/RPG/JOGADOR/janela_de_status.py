def JanelaDeBatalha():
    janela = {
        "jogador": jogador["nome"],
        "nível": jogador["nível"],
        "dano": jogador["dano"],
        "velocidade": jogador["velocidade"],
        "defesa": jogador["defesa"],
        "vida": f"{jogador["vida"]}/{jogador["vida máxima"]}",
        "arma": jogador["arma"],
        "experiencia": f"{jogador["experiencia"]}/{jogador["experiencia máxima"]}",
        "classe": jogador["classe"]
    }
    return janela

JanelaDeStatus = JanelaDeBatalha