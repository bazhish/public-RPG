import classe_do_player
classe_jogador = classe_do_player.classe_jogador
def status_jogador():
    ArmaInicial = "AdagaComum"
    AtributosJogador = 5
    
    DescriçãoJogador = {
        "nome": dados_pessoais["nome"],
        "idade": dados_pessoais["idade"],
        "peso": dados_pessoais["peso"],
        "sexo": dados_pessoais["sexo"],
        "altura": dados_pessoais["altura"],
        "nível": AtributosJogador,
        "dano": 10 * AtributosJogador,
        "velocidade": 7 * AtributosJogador,
        "defesa": 8 * AtributosJogador,
        "vida": 120 * AtributosJogador,
        "vida máxima": 1000,
        "arma": ArmaInicial,
        "experiencia": 0,
        "experiencia máxima": 300,
        "classe": classe_jogador,
        "escudo": "",
        "estamnina": 100,
        "estamnina máxima": 100,
        "habilidade passiva 1": classe_jogador.habilidade_passiva1,
        "habilidade passiva 2": classe_jogador.habilidade_passiva2,
        "habilidade passiva 3": classe_jogador.habilidade_passiva3,
        "habilidade ativa 1": classe_jogador.habilidade_ativa1,
        "habilidade ativa 2": classe_jogador.habilidade_ativa2,
    }
    
    return DescriçãoJogador

jogador = status_jogador()