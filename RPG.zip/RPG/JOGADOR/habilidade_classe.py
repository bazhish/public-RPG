# JOGADOR FICTICIO

jogador = {
    "nível": 78,
    "vida": 100,
    "dano": 20,
    "velocidade": 15,
    "defesa": 5,
    "arma": None,
    "estamina": 100,
}


class Habilidade:
    def __init__(
        self,
        nome,
        tipo,
        custo,
        tempo_de_recarga,
        efeito,
        nivel_minimo,
        duracao
    ):
        self.nome = nome
        self.tipo = tipo
        self.custo = custo
        self.tempo_de_recarga = tempo_de_recarga
        self.efeito = efeito
        self.nivel_minimo = nivel_minimo
        self.duracao = duracao
        self._cooldown_restante = 0.0

    def verifica_nivel(self) -> bool:
        return jogador["nível"] >  self.nivel_minimo

    def verifica_recurso(self) -> bool:
        if self.tipo == "passiva":
            return False
        
        return jogador.get("estamina", 0) >= self.custo
    
    def verifica_cooldown(self) -> bool:
        return self._cooldown_restante <= 0.0
        
    def pode_usar(self) -> bool:
        return (
            self.verifica_nivel() and
            self.verifica_recurso() and
            self.verifica_cooldown()
        )
    
    def usar(self, alvo=None) -> bool:
        if not self.pode_usar():
             return False

        if self.tipo == "ativa":
            jogador["estamina"] -= self.custo

        if callable(self.efeito):
            self.efeito(jogador, alvo)

        self._cooldown_restante = self.tempo_de_recarga
        return True

    def atualizar_cooldown(self, tempo):
        if self._cooldown_restante > 0:
            self._cooldown_restante = max(0, self._cooldown_restante - tempo)

#  HABILIDADES CLASSE: ASSASSINO
def Furtividade(jogador: dict, alvo: dict):
    jogador["velocidade"] += 10
    jogador["dano"] += 5
    jogador["defesa"] += 2
furtividade = Habilidade("Furtividade", "passiva", 0, 0.0, Furtividade, 20, 0)

def Evasao(jogador: dict, alvo: dict):
    jogador["velocidade"] += 5
    jogador["defesa"] += 3
evasao = Habilidade("Evasão", "passiva", 0, 0.0, Evasao, 30, 0)

def Sangramento(jogador: dict, alvo: dict):
    jogador["vida"] -= 50
    jogador["dano"] += 10
sangramento = Habilidade("Sangramento", "passiva", 0, 0.0, Sangramento, 40, 0)

def GolpeMortal(jogador: dict, alvo: dict):
    if alvo is None:
        pass

    dano_base = jogador["dano"]
    defesa_do_alvo = alvo["defesa"] * 0.8  
    dano_final = max(0, (dano_base * 3) - defesa_do_alvo)
    alvo["vida"] -= dano_final
    jogador["estamina"] += 10
golpe_mortal = Habilidade("Golpe mortal", "ativa", 30, 15.0, GolpeMortal, 60, 0)

def InvisibilidadeTemporaria(jogador: dict, alvo: dict):
    if alvo is None:
        pass
    jogador["velocidade"] += 15
    jogador["dano"] += 10
    jogador["defesa"] += 5
    jogador["estamina"] -= 20
invisibilidade_temporaria = Habilidade("Invisibilidade temporária", "ativa", 20, 10.0, InvisibilidadeTemporaria, 50, 5)

# HABILIDADES CLASSE: ESPADACHIM

def GolpeDeEspada(jogador: dict, alvo: dict):
    if jogador["arma"] is ("espada curta" or "espada longa" or "espada"):
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 2) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 15
golpe_de_espada = Habilidade("Golpe de espada", "passiva", 15, 10.0, GolpeDeEspada, 20, 0)

def DefesaDeEspada(jogador: dict, alvo: dict):
    if jogador["arma"] is ("espada curta" or "espada longa" or "espada"):
        jogador["defesa"] += 10
        jogador["estamina"] -= 10
defesa_de_espada = Habilidade("Defesa de espada", "passsiva", 10, 5.0, DefesaDeEspada, 15, 0)

def AtaqueRapido(jogador: dict, alvo: dict):
    if jogador["arma"] is ("espada curta" or "espada longa" or "espada"):
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 1.5) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 10
ataque_rapido = Habilidade("Ataque rápido", "passiva", 10, 5.0, AtaqueRapido, 15, 0)

def CortePreciso(jogador: dict, alvo: dict):
    if jogador["arma"] is ("espada curta" or "espada longa" or "espada"):
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 2.5) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 20
corte_preciso = Habilidade("Corte preciso", "ativa", 20, 15.0, CortePreciso, 30, 0)

def BloqueioDeEspada(jogador: dict, alvo: dict):
    if jogador["arma"] is ("espada curta" or "espada longa" or "espada"):
        jogador["defesa"] += 15
        jogador["estamina"] -= 15
bloqueio_de_espada = Habilidade("Bloqueio de espada", "ativa", 15, 10.0, BloqueioDeEspada, 25, 0)

# HABILIDDES CLASSE: ESCUDEIRO

def BloqueioDeAtaque(jogador: dict, alvo: dict):
    if jogador["arma"] is "escudo":
        jogador["defesa"] += 20
        jogador["estamina"] -= 10
bloqueio_de_ataque = Habilidade("Bloqueio de ataque", "passiva", 10, 5.0, BloqueioDeAtaque, 20, 0)

def ContraAtaque(jogador: dict, alvo: dict):
    if jogador["arma"] is "escudo":
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 1.5) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 15
contra_ataque = Habilidade("Contra-ataque", "passiva", 15, 10.0, ContraAtaque, 25, 0)

def ProtecaoDeAliados(jogador: dict, alvo: dict):
    if jogador["arma"] is "escudo":
        alvo["defesa"] += 10
        jogador["estamina"] -= 20
protecao_de_aliados = Habilidade("Proteção de aliados", "ativa", 20, 15.0, ProtecaoDeAliados, 30, 0)

def AtaqueComEscudo(jogador: dict, alvo: dict):
    if jogador["arma"] is "escudo":
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 2) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 15
ataque_com_escudo = Habilidade("Ataque com escudo", "ativa", 15, 10.0, AtaqueComEscudo, 20, 0)

def DefesaReforçada(jogador: dict, alvo: dict):
    if jogador["arma"] is "escudo":
        jogador["defesa"] += 25
        jogador["estamina"] -= 20
defesa_reforcada = Habilidade("Defesa reforçada", "ativa", 20, 15.0, DefesaReforçada, 35, 0)

# HABILIDADES CLASSE: LANCEIRO

def AtaqueDeLanca(jogador: dict, alvo: dict):
    if jogador["arma"] is "lança":
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 2) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 15
ataque_de_lanca = Habilidade("Ataque de lança", "passiva", 15, 10.0, AtaqueDeLanca, 20, 0)

def Empurrao(jogador: dict, alvo: dict):
    if jogador["arma"] is "lança":
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 1.5) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 10
empurrao = Habilidade("Empurrão", "passiva", 10, 5.0, Empurrao, 15, 0)

def AtaqueEmArea(jogador: dict, alvo: dict):
    if jogador["arma"] is "lança":
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 2.5) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 20
ataque_em_area = Habilidade("Ataque em área", "passiva", 20, 15.0, AtaqueEmArea, 30, 0)

def GolpeDeLanca(jogador: dict, alvo: dict):
    if jogador["arma"] is "lança":
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 3) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 25
golpe_de_lanca = Habilidade("Golpe de lança", "ativa", 25, 20.0, GolpeDeLanca, 40, 0)

def DefesaComLanca(jogador: dict, alvo: dict):
    if jogador["arma"] is "lança":
        jogador["defesa"] += 20
        jogador["estamina"] -= 15
defesa_com_lanca = Habilidade("Defesa com lança", "ativa", 15, 10.0, DefesaComLanca, 25, 0)

# HABILIDADES CLASSE: ARQUEIRO

def DisparoPreciso(jogador: dict, alvo: dict):
    if jogador["arma"] is "arco":
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 2) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 15
disparo_preciso = Habilidade("Disparo preciso", "passiva", 15, 10.0, DisparoPreciso, 20, 0)

def TiroRapido(jogador: dict, alvo: dict):
    if jogador["arma"] is "arco":
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 1.5) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 10
tiro_rapido = Habilidade("Tiro rápido", "passiva", 10, 5.0, TiroRapido, 15, 0)

def ChuvaDeFlechas(jogador: dict, alvo: dict):
    if jogador["arma"] is "arco":
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 2.5) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 20
chuva_de_flechas = Habilidade("Chuva de flechas", "passiva", 20, 15.0, ChuvaDeFlechas, 30, 0)

def DisparoExplosivo(jogador: dict, alvo: dict):
    if jogador["arma"] is "arco":
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 3) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 25
disparo_explosivo = Habilidade("Disparo explosivo", "ativa", 25, 20.0, DisparoExplosivo, 40, 0)

def Camuflagem(jogador: dict, alvo: dict):
    if jogador["arma"] is "arco":
        jogador["velocidade"] += 10
        jogador["dano"] += 5
        jogador["defesa"] += 2
        jogador["estamina"] -= 20
camuflagem = Habilidade("Camuflagem", "ativa", 20, 15.0, Camuflagem, 35, 5)

# HABILIDADES CLASSE: BATEDOR

def AtaqueSilencioso(jogador: dict, alvo: dict):
    if jogador["arma"] is "manopla":
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 1.5) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 10
ataque_silencioso = Habilidade("Ataque silencioso", "passiva", 10, 5.0, AtaqueSilencioso, 15, 0)

def EvasaoRapida(jogador: dict, alvo: dict):
    if jogador["arma"] is "manopla":
        jogador["velocidade"] += 10
        jogador["defesa"] += 5
        jogador["estamina"] -= 15
evasao_rapida = Habilidade("Evasão rápida", "passiva", 15, 10.0, EvasaoRapida, 20, 0)

def ExploracaoFurtiva(jogador: dict, alvo: dict):
    if jogador["arma"] is "manopla":
        jogador["velocidade"] += 5
        jogador["dano"] += 3
        jogador["defesa"] += 2
        jogador["estamina"] -= 10
exploracao_furtiva = Habilidade("Exploração furtiva", "passiva", 10, 5.0, ExploracaoFurtiva, 15, 0)

def AtaqueSurpresa(jogador: dict, alvo: dict):
    if jogador["arma"] is "manopla":
        dano_base = jogador["dano"]
        defesa_do_alvo = alvo["defesa"] * 0.8  
        dano_final = max(0, (dano_base * 2) - defesa_do_alvo)
        alvo["vida"] -= dano_final
        jogador["estamina"] -= 20

ataque_surpresa = Habilidade("Ataque surpresa", "ativa", 20, 15.0, AtaqueSurpresa, 30, 0)

def FugaRapida(jogador: dict, alvo: dict):
    if jogador["arma"] is "manopla":
        jogador["velocidade"] += 15
        jogador["dano"] += 10
        jogador["defesa"] += 5
        jogador["estamina"] -= 25
fuga_rapida = Habilidade("Fuga rápida", "ativa", 25, 20.0, FugaRapida, 35, 0)