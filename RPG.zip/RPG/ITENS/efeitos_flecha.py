import time

def veneno_efeito(duração):
    for x in range(duração):
        time.sleep(1.5)
        dano = 5
    return dano

def efeito_flamejante(duração):
    for x in range(duração):
        time.sleep(1.5)
        dano = 10
    return dano

class EfeitoFlecha:
    def __init__(self, nome, dano, tipo, alcance, duracao):
        self.nome = nome
        self.dano = dano
        self.tipo = tipo
        self.alcance = alcance
        self.duracao = duracao

class Veneno(EfeitoFlecha):
    def __init__(self):
        super().__init__("Veneno", veneno_efeito(5), "Dano ao longo do tempo", 10, 3)

class Assoviante(EfeitoFlecha):
    def __init__(self):
        super().__init__("Assoviante", 0, "Atração de inimigos", 15, 0)

class Flamejante(EfeitoFlecha):
    def __init__(self):
        super().__init__("Flamejante", efeito_flamejante(8), "Dano de fogo", 20, 2)

class Explosiva(EfeitoFlecha):
    def __init__(self):
        super().__init__("Explosiva", 30, "Dano em área", 25, 1)

class Paralisante(EfeitoFlecha):
    def __init__(self):
        super().__init__("Paralisante", 0, "Imobilização temporária", 12, 4)














