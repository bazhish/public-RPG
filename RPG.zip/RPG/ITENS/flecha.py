import random, efeitos_flecha
veneno = efeitos_flecha.Veneno()
assoviante = efeitos_flecha.Assoviante()
flamejante = efeitos_flecha.Flamejante()
explosiva = efeitos_flecha.Explosiva()
paralisante = efeitos_flecha.Paralisante()

# JOGADOR FICTICIO

jogador = {
    "nível": 78,
    "vida": 100,
    "dano": 20,
    "velocidade": 15,
    "defesa": 5,
    "arma": None
}

# CLASSE

class Flecha:
    def __init__(self, dano, peso):
        self.flecha = {}
        self.dano = dano
        self.peso = peso
        self.nível = 1
        self.raridades = ["comum", "rara", "épica", "lendaria"]
        self.raridade = ""
        self.efeitos = [veneno, assoviante, flamejante, explosiva, paralisante]
        self.efeito = ""

    def NívelComParametroJogador(self):
        nível = jogador["nível"]
        self.nível = random.randint(max(0, nível - 3), min(nível + 3, 100))

    def NivelComParamentroManual(self, nível):
        self.nível = nível

    def DanoDaFlecha(self):
        self.dano = self.dano * self.nível

    def EscolherRaridade(self, RaridadeEscolhida):
        if RaridadeEscolhida in self.raridades:
            self.raridade = RaridadeEscolhida

        else:
            print("Raridade inválida.")

    
    def EfeitoAleatorio(self):
        self.efeito = random.choice(self.efeitos)

    def EfeitoManual(self, efeito):
        if efeito in self.efeitos:
            self.efeito = efeito
        else:
            print("Efeito inválido.")

        return self.efeito
    
    def ClasseDaFlecha(self):
        self.flecha = {
            "Dano": self.dano,
            "Peso": self.peso,
            "Nível": self.nível,
            "Raridade": self.raridade,
        }

        if self.raridade == "rara":
            self.flecha["Dano"] *= 1.5

        elif self.raridade == "épica":
            self.flecha["Dano"] *= 2.3

        elif self.raridade == "lendaria":
            self.flecha["Dano"] *= 2.8

        return self.flecha
    
# FLECHAS

def FlechaComum():
    flecha = Flecha(3, 1)
    flecha.EscolherRaridade("comum")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

def FlechaRara():
    flecha = Flecha(4, 1)
    flecha.EscolherRaridade("rara")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

def FlechaEpica():
    flecha = Flecha(6, 1)
    flecha.EscolherRaridade("épica")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

def FlechaLendaria():
    flecha = Flecha(9, 1)
    flecha.EscolherRaridade("lendaria")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

# FLECHAS DUPLAS

def FlechaDuplaComum():
    flecha = Flecha(3, 1)
    flecha.EscolherRaridade("comum")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

def FlechaDuplaRara():
    flecha = Flecha(4, 1)
    flecha.EscolherRaridade("rara")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

def FlechaDuplaEpica():
    flecha = Flecha(6, 1)
    flecha.EscolherRaridade("épica")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

def FlechaDuplaLendaria():
    flecha = Flecha(9, 1)
    flecha.EscolherRaridade("lendaria")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha