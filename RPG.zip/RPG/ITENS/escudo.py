import random

# JOGADOR FICTICIO

jogador = {
    "nível": 78,
    "vida": 100,
    "dano": 20,
    "velocidade": 15,
    "defesa": 5,
    "arma": None
}

# CLASSE

class Escudo:
    def __init__(self, nome, defesa, peso):
        self.escudo = {}
        self.nome = nome
        self.defesa = defesa
        self.peso = peso
        self.nível = 1
        self.raridades = ["comum", "rara", "épica", "lendaria"]
        self.raridade = ""
        
    def NívelComParametroJogador(self):
        nível = jogador["nível"]
        self.nível = random.randint(max(0, nível - 3), min(nível + 3, 100))

    def NivelComParamentroManual(self, nível):
        self.nível = nível
    
    def DefesaDoEscudo(self):
        self.defesa = self.defesa * self.nível

    def VelocidadeQueOplayerIraPerder(self):
        if jogador["Escudo"] is not None:
            jogador["velocidade"] -= self.peso

    def EscolherRaridade(self, RaridadeEscolhida):
        if RaridadeEscolhida in self.raridades:
            self.raridade = RaridadeEscolhida

        else:
            print("Raridade inválida.")

    def AtributoAdicionalAleatorio(self):
        defesa = 2
        vida = 10
        velocidade = 3

        if self.raridade == "rara":
            defesa *= 1.5
            vida *= 1.5
            velocidade *= 1.5

        elif self.raridade == "épica":
            defesa *= 2.3
            vida *= 2.3
            velocidade *= 2.3

        elif self.raridade == "lendaria":
            defesa *= 2.8
            vida *= 2.8
            velocidade *= 2.8

        self.AtributoEscolhido = random.choice(["defesa", "vida", "velocidade"])

        if self.AtributoEscolhido == "defesa":
            jogador["defesa"] += defesa * self.nível

        elif self.AtributoEscolhido == "vida":
            jogador["vida"] += vida * self.nível

        elif self.AtributoEscolhido == "velocidade":
            jogador["velocidade"] += velocidade * self.nível

    def AtributoAdicionalManual(self, atributo):
        defesa = 2
        vida = 10
        velocidade = 3

        if self.raridade == "rara":
            defesa *= 1.5
            vida *= 1.5
            velocidade *= 1.5

        elif self.raridade == "épica":
            defesa *= 2.3
            vida *= 2.3
            velocidade *= 2.3

        elif self.raridade == "lendaria":
            defesa *= 2.8
            vida *= 2.8
            velocidade *= 2.8

        if atributo in ["defesa", "vida", "velocidade"]:
            self.AtributoEscolhido = atributo

            if self.AtributoEscolhido == "defesa":
                jogador["defesa"] += (defesa * self.nível)

            elif self.AtributoEscolhido == "vida":
                jogador["vida"] += (vida * self.nível)

            elif self.AtributoEscolhido == "velocidade":
                jogador["velocidade"] += (velocidade * self.nível)

        else:
            print("Atributo inválido.")

    def ClasseDoEscudo(self):

        self.escudo = {
            "Escudo": self.nome,
            "Raridade": self.raridade,
            "Nível": self.nível,
            "Defesa": self.defesa,
            "Peso": self.peso,
            "Atributo adicional": self.AtributoEscolhido,
        }

        if self.raridade == "rara":
            self.escudo["Defesa"] *= 1.5

        elif self.raridade == "épica":
            self.escudo["Defesa"] *= 2.3

        elif self.raridade == "lendaria":
            self.escudo["Defesa"] *= 2.8

        return self.escudo

# ESCUDO

def EscudoComum():
    escudo = Escudo("Escudo", 5, 3)
    escudo.EscolherRaridade("comum")
    escudo.NívelComParametroJogador()
    escudo.DefesaDoEscudo()
    escudo.AtributoAdicionalAleatorio()
    escudo.ClasseDoEscudo()
    return escudo

def EscudoRara():
    escudo = Escudo("Escudo", 7, 3)
    escudo.EscolherRaridade("rara")
    escudo.NívelComParametroJogador()
    escudo.DefesaDoEscudo()
    escudo.AtributoAdicionalAleatorio()
    escudo.ClasseDoEscudo()
    return escudo

def EscudoEpica():
    escudo = Escudo("Escudo", 10, 2)
    escudo.EscolherRaridade("épica")
    escudo.NívelComParametroJogador()
    escudo.DefesaDoEscudo()
    escudo.AtributoAdicionalAleatorio()
    escudo.ClasseDoEscudo()
    return escudo

def EscudoLendaria():
    escudo = Escudo("Escudo", 15, 2)
    escudo.EscolherRaridade("lendaria")
    escudo.NívelComParametroJogador()
    escudo.DefesaDoEscudo()
    escudo.AtributoAdicionalAleatorio()
    escudo.ClasseDoEscudo()
    return escudo
