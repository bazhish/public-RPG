import random, efeitos_dardos

veneno = efeitos_dardos.Veneno()
assoviante = efeitos_dardos.Assoviante()
flamejante = efeitos_dardos.Flamejante()
explosiva = efeitos_dardos.Explosiva()
paralisante = efeitos_dardos.Paralisante()
tranquilizante = efeitos_dardos.Tranquilizante()


# JOGADOR FICTICIO

jogador = {
    "nível": 78,
    "vida": 100,
    "dano": 20,
    "velocidade": 15,
    "defesa": 5,
    "arma": None
}

# CLASSE

class Dardos:
    def __init__(self, dano, peso):
        self.dardos = {}
        self.dano = dano
        self.peso = peso
        self.nível = 1
        self.raridades = ["comum", "rara", "épica", "lendaria"]
        self.raridade = ""
        self.efeitos = [veneno, assoviante, flamejante, explosiva, paralisante, tranquilizante]
        self.efeito = ""

    def NívelComParametroJogador(self):
        nível = jogador["nível"]
        self.nível = random.randint(max(0, nível - 3), min(nível + 3, 100))

    def NivelComParamentroManual(self, nível):
        self.nível = nível

    def DanoDoDardo(self):
        self.dano = self.dano * self.nível

    def EscolherRaridade(self, RaridadeEscolhida):
        if RaridadeEscolhida in self.raridades:
            self.raridade = RaridadeEscolhida

        else:
            print("Raridade inválida.")

    def EfeitoAleatorio(self):
        self.efeito = random.choice(self.efeitos)

    def EfeitoManual(self, efeito):
        if efeito in self.efeitos:
            self.efeito = efeito
        else:
            print("Efeito inválido.")

        return self.efeito
    
    def ClasseDoDardo(self):
        self.dardos = {
            "Dano": self.dano,
            "Peso": self.peso,
            "Nível": self.nível,
            "Raridade": self.raridade,
            "Efeito": self.efeito,
        }

        if self.raridade == "rara":
            self.dardos["Dano"] *= 1.5

        elif self.raridade == "épica":
            self.dardos["Dano"] *= 2.3

        elif self.raridade == "lendaria":
            self.dardos["Dano"] *= 2.8

        return self.dardos
    
# DARDOS

def DardoComum():
    dardo = Dardos(3, 1)
    dardo.EscolherRaridade("comum")
    dardo.NívelComParametroJogador()
    dardo.DanoDoDardo()
    dardo.EfeitoAleatorio()
    dardo.ClasseDoDardo()
    return dardo

def DardoRara():
    dardo = Dardos(4, 1)
    dardo.EscolherRaridade("rara")
    dardo.NívelComParametroJogador()
    dardo.DanoDoDardo()
    dardo.EfeitoAleatorio()
    dardo.ClasseDoDardo()
    return dardo

def DardoEpica():
    dardo = Dardos(6, 1)
    dardo.EscolherRaridade("épica")
    dardo.NívelComParametroJogador()
    dardo.DanoDoDardo()
    dardo.EfeitoAleatorio()
    dardo.ClasseDoDardo()
    return dardo

def DardoLendaria():
    dardo = Dardos(9, 1)
    dardo.EscolherRaridade("lendaria")
    dardo.NívelComParametroJogador()
    dardo.DanoDoDardo()
    dardo.EfeitoAleatorio()
    dardo.ClasseDoDardo()
    return dardo

