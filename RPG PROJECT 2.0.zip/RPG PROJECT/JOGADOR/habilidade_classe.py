

# JOGADOR FICTICIO

jogador = {
    "nível": 78,
    "vida": 100,
    "dano": 20,
    "velocidade": 15,
    "defesa": 5,
    "arma": None,
    "estamina": 100,
}

class Habilidade:
    def __init__(self,nome,tipo,custo,tempo_de_recarga,efeito,nivel_minimo,duracao):
        self.nome = nome
        self.tipo = tipo
        self.custo = custo
        self.tempo_de_recarga = tempo_de_recarga
        self.efeito = efeito
        self.nivel_minimo = nivel_minimo
        self.duracao = duracao
        self._cooldown_restante = 0.0

    def verifica_nivel(self) -> bool:
        return jogador["nível"] >  self.nivel_minimo

    def verifica_recurso(self) -> bool:
        if self.tipo == "passiva":
            return False
        
        return jogador.get("estamina", 0) >= self.custo
    
    def verifica_cooldown(self) -> bool:
        return self._cooldown_restante <= 0.0
        
    def pode_usar(self) -> bool:
        return (
            self.verifica_nivel() and
            self.verifica_recurso() and
            self.verifica_cooldown()
        )
    
    def usar(self, alvo=None) -> bool:
        if not self.pode_usar():
             return False

        if self.tipo == "ativa":
            jogador["estamina"] -= self.custo

        if callable(self.efeito):
            self.efeito(jogador, alvo)

        self._cooldown_restante = self.tempo_de_recarga
        return True

    def atualizar_cooldown(self, tempo):
        if self._cooldown_restante > 0:
            self._cooldown_restante = max(0, self._cooldown_restante - tempo)

#  HABILIDADES CLASSE: ASSASSINO
def Furtividade():
    jogador["velocidade"] += 10
    jogador["dano"] -= 2
    jogador["defesa"] -= 3
furtividade = Habilidade("Furtividade", "passiva", 0, 0.0, Furtividade, 20, 0)

def Evasao():
    jogador["velocidade"] += 7
    jogador["defesa"] += 6
    jogador["vida"] += 10
evasao = Habilidade("Evasão", "passiva", 0, 0.0, Evasao, 30, 0)

def Sangramento():
    jogador["vida"] -= 50
    jogador["dano"] += 25
sangramento = Habilidade("Sangramento", "passiva", 0, 0.0, Sangramento, 40, 0)

def GolpeMortal(jogador: dict, alvo: dict):
    if alvo is None:
        pass

    dano_base = jogador["dano"]
    defesa_do_alvo = alvo["defesa"] * 0.75  
    dano_final = max(0, (dano_base * 3) - defesa_do_alvo)
    alvo["vida"] -= dano_final
golpe_mortal = Habilidade("Golpe mortal", "ativa", 30, 15.0, GolpeMortal, 60, 0)

def InvisibilidadeTemporaria(jogador: dict, alvo: dict):
    if alvo is None:
        pass
    jogador["velocidade"] += 15
    jogador["dano"] += 15
    jogador["defesa"] -= 20
invisibilidade_temporaria = Habilidade("Invisibilidade temporária", "ativa", 20, 10.0, InvisibilidadeTemporaria, 50, 5)

# HABILIDADES CLASSE: ESPADACHIM

def VontadeDaEspada():
    jogador["vida"] = 5
    jogador["defesa"] = 2
    jogador["estamina"] = 8
vontade_da_espada = Habilidade("Vontade Da Espada", "passiva", 15, 10.0, VontadeDaEspada, 20, 0)

def HerançaDaEspada():
    jogador["dano"] += 10
    jogador["estamina"] += 5
    jogador["velocidade"] += 8
herança_da_espada = Habilidade("Herança da espada", "passsiva", 10, 5.0, HerançaDaEspada, 15, 0)

def AtaqueRapido():
    jogador["estamina"] += 7
    jogador["velocidade"] += 9
ataque_rapido = Habilidade("Ataque rápido", "passiva", 10, 5.0, AtaqueRapido, 15, 0)

def ImpactoCruzado(jogador: dict, alvo: dict):
    dano_base = jogador["dano"]
    defesa_do_alvo = alvo["defesa"] * 0.8  
    dano_final = max(0, (dano_base * 2.5) - defesa_do_alvo)
    alvo["vida"] -= dano_final
    jogador["estamina"] -= 20
impacto_cruzado = Habilidade("Impacto cruzado", "ativa", 20, 15.0, ImpactoCruzado, 30, 0)

def BloqueioDeEspada(jogador: dict, alvo: dict):
    jogador["defesa"] += 20
bloqueio_de_espada = Habilidade("Bloqueio de espada", "ativa", 15, 10.0, BloqueioDeEspada, 25, 0)

# HABILIDDES CLASSE: ESCUDEIRO

def BloqueioDeAtaque():
    jogador["defesa"] += 16
    jogador["vida"] += 12
bloqueio_de_ataque = Habilidade("Bloqueio de ataque", "passiva", 10, 5.0, BloqueioDeAtaque, 20, 0)

def ContraAtaque(jogador: dict, alvo: dict):
    dano_final = alvo["dano"] * 0.75
    alvo["vida"] -= dano_final
    jogador["estamina"] -= 15
contra_ataque = Habilidade("Contra-ataque", "passiva", 15, 10.0, ContraAtaque, 25, 0)

def PesoPena():
    jogador["estamina"] += 10
    jogador["velocidade"] +=30
peso_pena = Habilidade("Peso pena", "passiva", 20, 15.0, PesoPena, 30, 0)

def AtaqueComEscudo(jogador: dict, alvo: dict):
    dano_base = jogador["dano"]
    defesa_do_alvo = alvo["defesa"] * 0.8  
    dano_final = max(0, (dano_base * 2) - defesa_do_alvo)
    alvo["vida"] -= dano_final
    jogador["estamina"] -= 15
ataque_com_escudo = Habilidade("Ataque com escudo", "ativa", 15, 10.0, AtaqueComEscudo, 20, 0)

def DefesaReforçada(jogador: dict, alvo: dict):
    jogador["defesa"] += 30
    jogador["estamina"]+= 20
defesa_reforcada = Habilidade("Defesa reforçada", "ativa", 20, 15.0, DefesaReforçada, 35, 0)

# HABILIDADES CLASSE: LANCEIRO

def DançaDaLança():
    jogador["estamina"] += 7
    jogador["velocidade"] +=2
danca_da_lanca = Habilidade("Dança da lança", "passiva", 15, 10.0, DançaDaLança, 20, 0)

def ControlePassivo():
    jogador["estamina"] += 7
    jogador["defesa"] +=4
    jogador["velocidade"] +=2
    jogador["dano"] +=3
controle_passivo = Habilidade("Controle Passivo", "passiva", 10, 5.0, ControlePassivo, 15, 0)

def ControlTotal():
    jogador["estamina"] += 13
    jogador["defesa"] +=5
    jogador["velocidade"] +=8
    jogador["vida"] += 12
    jogador["dano"] +=9
controle_total = Habilidade("Controle tottal", "passiva", 20, 15.0, ControlTotal, 30, 0)

def GiroDeLanca(jogador: dict, alvo: dict):
    dano_base = jogador["dano"]
    defesa_do_alvo = alvo["defesa"] * 0.5
    dano_final = max(0, (dano_base * 3) - defesa_do_alvo)
    alvo["vida"] -= dano_final
    jogador["estamina"] -= 25
golpe_de_lanca = Habilidade("Giiro de lança", "ativa", 25, 20.0, GolpeDeLanca, 40, 0)

def ArremessoDeLanca(jogador: dict, alvo: dict):
    dano_base = jogador["dano"]
    defesa_do_alvo = alvo["defesa"] * 0.5
    dano_final = max(0, (dano_base * 2) - defesa_do_alvo)
    alvo["vida"] -= dano_final
    jogador["estamina"] -= 20
arremesso_de_lança = Habilidade("Arremesso de lança", "ativa", 15, 10.0, ArremessoDeLanca, 25, 0)

# HABILIDADES CLASSE: ARQUEIRO

def DisparoPreciso():
    jogador["velocidade"] -= 7
    jogador["dano"] += 9
    jogador["defesa"] -= 6
disparo_preciso = Habilidade("Disparo preciso", "passiva", 15, 10.0, DisparoPreciso, 20, 0)

def PassosSilenciosos():
    jogador["velocidade"] += 12
    jogador["defesa"] -= 9
    jogador["vida"] += 15
passos_silenciosos = Habilidade("Passos silênciosos", "passiva", 10, 5.0, PassosSilenciosos, 15, 0)

def FlechaDupla():
    jogador["dano"] * 1.75
    jogador["velocidade"] * 0.8
flecha_dupla = Habilidade("Flecha dupla", "passiva", 20, 15.0, FlechaDupla, 30, 0)

def DisparoExplosivo(jogador: dict, alvo: dict):
    dano_base = jogador["dano"]
    defesa_do_alvo = alvo["defesa"] * 0.5  
    dano_final = max(0, (dano_base * 5) - defesa_do_alvo)
    alvo["vida"] -= dano_final
    jogador["estamina"] -= 30
disparo_explosivo = Habilidade("Disparo explosivo", "ativa", 25, 20.0, DisparoExplosivo, 40, 0)

def Camuflagem(jogador: dict, alvo: dict):
    jogador["velocidade"] += 10
    jogador["dano"] += 5
    jogador["defesa"] += 2
    jogador["estamina"] -= 20
camuflagem = Habilidade("Camuflagem", "ativa", 20, 15.0, Camuflagem, 35, 5)

# HABILIDADES CLASSE: BATEDOR

def AtaqueSilencioso():
    jogador["velocidade"] += 7
    jogador["defesa"] -= 15
ataque_silencioso = Habilidade("Ataque silencioso", "passiva", 10, 5.0, AtaqueSilencioso, 15, 0)

def EvasaoRapida():
    jogador["velocidade"] += 10
    jogador["defesa"] += 5
    jogador["estamina"] -= 15
evasao_rapida = Habilidade("Evasão rápida", "passiva", 15, 10.0, EvasaoRapida, 20, 0)

def ExploracaoFurtiva():
    jogador["velocidade"] += 5
    jogador["dano"] += 3
    jogador["defesa"] += 2
    jogador["estamina"] -= 10
exploracao_furtiva = Habilidade("Exploração furtiva", "passiva", 10, 5.0, ExploracaoFurtiva, 15, 0)

def AtaqueSurpresa(jogador: dict, alvo: dict):
    dano_base = jogador["dano"]
    defesa_do_alvo = alvo["defesa"] * 0.8  
    dano_final = max(0, (dano_base * 2) - defesa_do_alvo)
    alvo["vida"] -= dano_final
    jogador["estamina"] -= 20
ataque_surpresa = Habilidade("Ataque surpresa", "ativa", 20, 15.0, AtaqueSurpresa, 30, 0)

def FugaRapida(jogador: dict, alvo: dict):
    jogador["velocidade"] += 15
    jogador["dano"] += 10
    jogador["defesa"] += 5
    jogador["estamina"] -= 25
fuga_rapida = Habilidade("Fuga rápida", "ativa", 25, 20.0, FugaRapida, 35, 0)