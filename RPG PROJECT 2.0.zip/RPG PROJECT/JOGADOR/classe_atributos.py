import JOGADOR.habilidade_classe as habilidade_classe
import armas

# HABILIDADES CLASSE: ASSASSINO

furtividade = habilidade_classe.furtividade
evasão = habilidade_classe.evasao
sangramento = habilidade_classe.sangramento
golpe_mortal = habilidade_classe.golpe_mortal
invisibilidade_temporária = habilidade_classe.invisibilidade_temporaria

# HABILIDADES CLASSE: ESPADACHIM

golpe_de_espada = habilidade_classe.golpe_de_espada
defesa_de_espada = habilidade_classe.defesa_de_espada
ataque_rapido = habilidade_classe.ataque_rapido
corte_preciso = habilidade_classe.corte_preciso
bloqueio_de_espada = habilidade_classe.bloqueio_de_espada

# HABILIDADES CLASSE: ESCUDEIRO

bloqueio_de_ataque = habilidade_classe.bloqueio_de_ataque
contra_ataque = habilidade_classe.contra_ataque
proteção_de_aliados = habilidade_classe.protecao_de_aliados
ataque_com_escudo = habilidade_classe.ataque_com_escudo
defesa_reforcada = habilidade_classe.defesa_reforcada

# HABILIDADES CLASSE: LANCEIRO

ataque_de_lança = habilidade_classe.ataque_de_lanca
empurrao = habilidade_classe.empurrao
ataque_em_area = habilidade_classe.ataque_em_area
golpe_de_lanca = habilidade_classe.golpe_de_lanca
defesa_com_lanca = habilidade_classe.defesa_com_lanca

# HABILIDADES CLASSE: ARQUEIRO

disparo_preciso = habilidade_classe.disparo_preciso
tiro_rapido = habilidade_classe.tiro_rapido
chuva_de_flechas = habilidade_classe.chuva_de_flechas
disparo_explosivo = habilidade_classe.disparo_explosivo
camuflagem = habilidade_classe.camuflagem

# HABILIDADES CLASSE: BATEDOR

ataque_silencioso = habilidade_classe.ataque_silencioso
evasao_agil = habilidade_classe.evasao_rapida
exploracao_furtiva = habilidade_classe.exploracao_furtiva
ataque_surpresa = habilidade_classe.ataque_surpresa
fuga_rapida = habilidade_classe.fuga_rapida

class Classe:
    def __init__(self, classe ,dano_padrão, velocidade_padrão, defesa_padrão, vida_máxima_padrão, arma_inicial, multiplicador_de_experiência, habilidade_passiva1, habilidade_passiva2, habilidade_passiva3, habilidade_ativa1, habilidade_ativa2):
        
        self.classe = classe
        self.dano_padrão = dano_padrão
        self.velocidade_padrão = velocidade_padrão
        self.defesa_padrão = defesa_padrão
        self.vida_máxima_padrão = vida_máxima_padrão
        self.arma_inicial = arma_inicial
        self.multiplicador_de_experiência = multiplicador_de_experiência
        self.habilidade_passiva1 = habilidade_passiva1
        self.habilidade_passiva2 = habilidade_passiva2
        self.habilidade_passiva3 = habilidade_passiva3
        self.habilidade_ativa1 = habilidade_ativa1
        self.habilidade_ativa2 = habilidade_ativa2

class Assassino(Classe):
    def __init__(self):
        super().__init__("Assassino", 10, 5, 2, 10, "Adaga", 1.5, furtividade, evasão, sangramento, golpe_mortal, invisibilidade_temporária)

class Espadachim(Classe):
    def __init__(self):
        super().__init__("Espadachim", 12, 4, 3, 12, "Espada Curta", 1.2, golpe_de_espada, defesa_de_espada, ataque_rapido, corte_preciso, bloqueio_de_espada)

class Escudeiro(Classe):
    def __init__(self):
        super().__init__("Escudeiro", 8, 3, 5, 15, "Escudo", 1.0, bloqueio_de_ataque, contra_ataque, proteção_de_aliados, ataque_com_escudo, defesa_reforcada) 

class Lanceiro(Classe):
    def __init__(self):
        super().__init__("Lanceiro", 11, 4, 4, 13, "Lança", 1.3, ataque_de_lança, empurrao, ataque_em_area, golpe_de_lanca, defesa_com_lanca)

class Arqueiro(Classe):
    def __init__(self):
        super().__init__("Arqueiro", 9, 6, 2, 11, "Arco e Flecha", 1.4, disparo_preciso, tiro_rapido, chuva_de_flechas, disparo_explosivo, camuflagem)

class Batedor(Classe):
    def __init__(self):
        super().__init__("Batedor", 7, 5, 3, 14, "manopla", 1.1, ataque_silencioso, evasao_agil, exploracao_furtiva, ataque_surpresa, fuga_rapida)

assassino = Assassino()
espadachim = Espadachim()
escudeiro = Escudeiro()
lanceiro = Lanceiro()
arqueiro = Arqueiro()
batedor = Batedor()