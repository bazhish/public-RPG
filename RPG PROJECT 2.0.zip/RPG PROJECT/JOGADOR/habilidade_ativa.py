# JOGADOR FICTICIO
from random import uniform
import jogador_ficticio
jogador = jogador_ficticio.jogador

# HABILIDADE ATIVA

class HabilidadeAtiva:  # MOLDE PARA HABILIDADE ATIVA
    def __init__(self, nome, efeito, custo, tempo_de_recarga, nivel_minimo, duracao):
        self.nome = nome # NOME DA HABILIDADE
        self.custo = custo # CUSTO DE ESTAMINA PARA USAR A HABILIDADE
        self.efeito = efeito # EFEITO QUE A HABILIDADE APLICA SOBRE O JOGADOR
        self.tempo_de_recarga = tempo_de_recarga # TEMPO DE RECARGA DA HABILIDADE EM TURNOS
        self.tempo_de_recarga_restante = 0  # TEMPO DE RECARGA RESTANTE
        self.nível_mínimo = nivel_minimo # NÍVEL MÍNIMO PARA USAR A HABILIDADE
        self.duracao = duracao # DURAÇÃO DA HABILIDADE EM TURNOS
        self.duracao_restante = 0
        self.uso = None  # VERIFICA SE A HABILIDADE PODE SER APLICADA OU NÃO

    def verificar_nível(self): # VERIFICA SE O JOGADOR TEM NÍVEL SUFICIENTE PARA USAR A HABILIDADE
        if jogador["nível"] >= self.nível_mínimo:
            self.uso = True
        else: 
            self.uso = False

    def aplicar_habilidade(self): # APLICA A HABILIDADE SE O JOGADOR TIVER NÍVEL SUFICIENTE E ESTAMINA SUFICIENTE
        if self.uso == True:
            if jogador["estamina"] >= self.custo:
                if self.tempo_de_recarga_restante == 0:
                    jogador["estamina"] -= self.custo
                    self.efeito(jogador)
                    self.duracao_restante = self.duracao
                    self.tempo_de_recarga_restante = self.tempo_de_recarga

    def atualizar_turno(self): # ATUALIZA O ESTADO DA HABILIDADE A CADA TURNO
        if self.duracao_restante > 0:
            self.duracao_restante -= 1

        if self.tempo_de_recarga_restante > 0:
            self.tempo_de_recarga_restante -= 1

# HABILIDADE ATIVA CLASSE: ASSASSINO

def efeito_golpe_mortal(jogador, alvo):
    if alvo is None:
        pass

    else:
        dano_base = jogador["dano"]
        reducao_de_defesa = alvo["defesa"] * (uniform(0.6, 0.8))
        dano_final = max(0, (dano_base*3) - reducao_de_defesa)
        alvo["vida"] -= dano_final
golpe_mortal = HabilidadeAtiva("Golpe mortal", efeito_golpe_mortal, 100, 2, 50, 1)

def efeito_intangibilidade(jogador, alvo):
    if alvo is None:
        pass

    else:
        alvo["dano"] = 0
intangibilidade = HabilidadeAtiva("Intangibilidade", efeito_intangibilidade, 70, 1, 80, 1)

# HABILIDADE ATIVA CLASSE: ESPADACHIN

def efeito_impacto_cruzado(jogador, alvo):
    if alvo is None:
        pass

    dano_base = jogador["dano"]
    reducao_de_defesa = alvo["dano"] * 0.5
    dano_final = max(0, (dano_base * 2) - reducao_de_defesa)
    alvo["vida"] -= dano_final
impacto_cruzado = HabilidadeAtiva("Impacto cruzado", efeito_impacto_cruzado, 90, 2, 50, 1)

def efeito_bloqueio_de_espada(jogador, alvo):
    if alvo is None:
        pass

    alvo["dano"] * 0.3
bloqueio_de_espada = HabilidadeAtiva("Bloqueio de espada", efeito_bloqueio_de_espada, 85, 1, 80, 1)

# HABILIDADE ATIVA CLASSE: 

