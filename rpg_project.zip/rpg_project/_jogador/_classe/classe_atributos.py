from _habilidades.habilidade_ativa import golpe_mortal, intangibilidade, impacto_cruzado, bloqueio_de_espada, ataque_com_escudo, defesa_reforçada, giro_de_lança, arremesso_de_lança, disparo_perfurante, camuflagem, ataque_surpresa, fuga_rapida 
from _habilidades.habilidade_passiva import furtividade, evasão, sangramento, vontade_da_espada, herança_da_espada, ataque_rapido, bloqueio_de_ataque, repelir, peso_pena, dança_da_lança, controle_passivo, controle_total, disparo_preciso, passos_silenciosos, flecha_dupla, ataque_silencioso, evasao_rapida, exploracao_furtiva
from _itens._armas.armas_iniciais import adaga_sem_ponta, espada_cega, lança_com_cabo_quebrado, arco_e_flecha_velhos, soco_espinhado, escudo_de_mao

class Classe:
    def __init__(self, classe ,dano_padrão, velocidade_padrão, defesa_padrão, vida_máxima_padrão, arma_inicial, multiplicador_de_experiência, habilidade_passiva1, habilidade_passiva2, habilidade_passiva3, habilidade_ativa1, habilidade_ativa2):
        
        self.classe = classe
        self.dano_padrão = dano_padrão
        self.velocidade_padrão = velocidade_padrão
        self.defesa_padrão = defesa_padrão
        self.vida_máxima_padrão = vida_máxima_padrão
        self.arma_inicial = arma_inicial
        self.multiplicador_de_experiência = multiplicador_de_experiência
        self.habilidade_passiva1 = habilidade_passiva1
        self.habilidade_passiva2 = habilidade_passiva2
        self.habilidade_passiva3 = habilidade_passiva3
        self.habilidade_ativa1 = habilidade_ativa1
        self.habilidade_ativa2 = habilidade_ativa2

class Assassino(Classe):
    def __init__(self):
        super().__init__("Assassino", 10, 5, 2, 10, adaga_sem_ponta, 1.5, furtividade, evasão, sangramento, golpe_mortal, intangibilidade)

class Espadachim(Classe):
    def __init__(self):
        super().__init__("Espadachim", 12, 4, 3, 12, espada_cega, 1.2, vontade_da_espada, herança_da_espada, ataque_rapido, impacto_cruzado, bloqueio_de_espada)

class Escudeiro(Classe):
    def __init__(self):
        super().__init__("Escudeiro", 8, 3, 5, 15, escudo_de_mao, 1.0, bloqueio_de_ataque, repelir, peso_pena, ataque_com_escudo, defesa_reforçada) 

class Lanceiro(Classe):
    def __init__(self):
        super().__init__("Lanceiro", 11, 4, 4, 13, lança_com_cabo_quebrado, 1.3, dança_da_lança, controle_passivo, controle_total, giro_de_lança, arremesso_de_lança)

class Arqueiro(Classe):
    def __init__(self):
        super().__init__("Arqueiro", 9, 6, 2, 11, arco_e_flecha_velhos, 1.4, disparo_preciso, passos_silenciosos, flecha_dupla, disparo_perfurante, camuflagem)

class Batedor(Classe):
    def __init__(self):
        super().__init__("Batedor", 7, 5, 3, 14, soco_espinhado, 1.1, ataque_silencioso, evasao_rapida, exploracao_furtiva, ataque_surpresa, fuga_rapida)

assassino = Assassino()
espadachim = Espadachim()
escudeiro = Escudeiro()
lanceiro = Lanceiro()
arqueiro = Arqueiro()
batedor = Batedor()