# HABILIDADE PASSIVA

class HabilidadePassiva: # MOLDE PARA HABILIDADE PASSIVA
    def __init__ (self, nome, efeito, nível_mínimo):
        self.nome = nome # NOME DA HABILIDADE
        self.efeito = efeito # EFEITO QUE HABILIDADE APLICA SOBRE O PRÓPIO USUARIO
        self.nível_mínimo = nível_mínimo # NÍVEL MÍNIMO PARA USAR A HABILIDADE
        self.aplicar = None # VERIFICA SE A HABILIDADE PODE SER APLICADA OU NÃO

    def verificar_nível(self, usuario): # VERIFICA SE O USUARIO TEM NÍVEL SUFICIENTE PARA USAR A HABILIDADE
        if usuario["nível"] >= self.nível_mínimo:
            self.aplicar = True
        else: 
            self.aplicar = False

    def aplicar_habilidade(self, usuario): # APLICA A HABILIDADE SE O USUARIO TIVER NÍVEL SUFICIENTE
        if self.aplicar == True:
            self.efeito(usuario)
        else:
            pass

# HABILIDADES PASSIVAS CLASSSE: ASSASSINO

def efeito_furtividade(usuario):
    usuario["dano"] *= 1.25
    usuario["velocidade"] *= 1.25
    usuario["defesa"] *= 0.75
    usuario["estamina"] *= 0.75
    usuario["vida"] *= 1.25
furtividade = HabilidadePassiva("furtividade", efeito_furtividade, 12)

def efeito_evasão(usuario):
    usuario["velocidade"] *= 1.5
    usuario["defesa"] *= 1.5
    usuario["estamina"] *= 1.5
    usuario["vida"] *= 1.5
evasão = HabilidadePassiva("evsão", efeito_evasão, 45)

def efeito_sangramento(usuario):
    usuario["dano"] *= 2
    usuario["vida"] *= 0.8
sangramento = HabilidadePassiva("sangramento", efeito_sangramento, 70)

# HABILIDADES PASSIVAS CLASSE: ESPADACHIN

def efeito_vontade_da_espada(usuario):
    usuario["dano"] *= 1.2
    usuario["velocidade"] *= 1.2
    usuario["defesa"] *= 1.2
    usuario["estamina"] *= 1.2
    usuario["vida"] *= 1.2
vontade_da_espada = HabilidadePassiva("vontade da espada", efeito_vontade_da_espada, 12)

def efeito_herança_da_espada(usuario):
    usuario["dano"] *= 1.45
    usuario["velocidade"] *= 1.45
    usuario["defesa"] *= 1.45
    usuario["estamina"] *= 1.45
    usuario["vida"] *= 1.45
herança_da_espada = HabilidadePassiva("herança da espada", efeito_herança_da_espada, 45)

def efeito_ataque_rápido(usuario):
    usuario["dano"] *= 1.85
    usuario["velocidade"] *= 1.85
    usuario["defesa"] *= 0.7
    usuario["estamina"] *= 0.9
ataque_rapido = HabilidadePassiva("ataque rápido", efeito_ataque_rápido, 70)

# HABILIDADES PASSIVAS CLASSE: ESCUDEIRO

def efeito_bloqueio_de_ataque(usuario):
    usuario["defesa"] *= 2
    usuario["estamina"] *= 1.75
    usuario["vida"] *= 1.1
bloqueio_de_ataque = HabilidadePassiva("bloqueio de ataque", efeito_bloqueio_de_ataque, 12)

def efeito_repelir(adversário):
    dano = (adversário["dano"] * 0.75)
    adversário["defesa"] *= 0.5
    adversário["vida"] -= dano
repelir = HabilidadePassiva("repelir", efeito_repelir, 45)

def efeito_peso_pena(usuario):
    usuario["velocidade"] *= 1.5
    usuario["estamina"] *= 1.5
    usuario["vida"] *= 1.5
peso_pena = HabilidadePassiva("peso pena", efeito_peso_pena, 70)

# HABILIDADES PASSIVAS CLASSE: LANÇEIRO

def efeito_dança_da_lança(usuario):
    usuario["estamina"] *= 1.3
    usuario["velocidade"] *= 1.3
dança_da_lança = HabilidadePassiva("dança da lança", efeito_dança_da_lança, 12)

def efeito_controle_passivo(usuario):
    usuario["estamina"] *= 1.2
    usuario["defesa"] *= 1.5
    usuario["velocidade"] *= 1.2
    usuario["dano"] *= 1.5
    usuario["vida"] *= 1.5
controle_passivo = HabilidadePassiva("controle passivo", efeito_controle_passivo, 45)

def efeito_controle_total(usuario):
    usuario["estamina"] *= 1.35
    usuario["defesa"] *= 1.35
    usuario["velocidade"] *= 1.35
    usuario["dano"] *= 1.35
    usuario["vida"] *= 1.35
controle_total = HabilidadePassiva("controle total", efeito_controle_total, 70)

# HABILIDADES PASSIVAS CLASSE: ARQUEIRO

def efeito_disparo_preciso(usuario):
    usuario["dano"] *= 1.25
    usuario["velocidade"] *= 0.75
    usuario["defesa"] *= 0.75
disparo_preciso = HabilidadePassiva("disparo preciso", efeito_disparo_preciso, 12)

def efeito_passos_silenciosos(usuario):
    usuario["velocidade"] *= 1.4
    usuario["estamina"] *= 1.4
    usuario["vida"] *= 1.4
    usuario["defesa"] *= 0.6
passos_silenciosos = HabilidadePassiva("passos silenciosos", efeito_passos_silenciosos, 45)

def efeito_flecha_dupla(usuario):
    usuario["dano"] *= 1.75
    usuario["velocidade"] *= 0.8
    usuario["defesa"] *= 0.8
flecha_dupla = HabilidadePassiva("flecha dupla", efeito_flecha_dupla, 70)
    
# HABILIDADES PASSIVAS CLASSE: BATEDOR

def efeito_ataque_silencioso(usuario):
    usuario["velocidade"] *= 1.8
    usuario["defesa"] *= 0.85
    usuario["dano"] *= 1.3
ataque_silencioso = HabilidadePassiva("ataque silencioso", efeito_ataque_silencioso, 12)

def efeito_evasão_rápida(usuario):
    usuario["velocidade"] *= 1.5
    usuario["defesa"] *= 1.2
    usuario["estamina"] *= 0.7
    usuario["vida"] *= 1.5
evasao_rapida = HabilidadePassiva("evasão rápida", efeito_evasão_rápida, 45)

def efeito_exploracao_furtiva(usuario):
    usuario["velocidade"] *= 1.3
    usuario["dano"] *= 1.2
    usuario["defesa"] *= 1.1
    usuario["estamina"] *= 0.9
    usuario["vida"] *= 1.3
exploracao_furtiva = HabilidadePassiva("Exploração furtiva", efeito_exploracao_furtiva, 70)