# JOGADOR FICTICIO

from _jogador._jogador.jogador_ficticio import jogador

# HABILIDADE PASSIVA

class HabilidadePassiva: # MOLDE PARA HABILIDADE PASSIVA
    def __init__ (self, nome, efeito, nível_mínimo):
        self.nome = nome # NOME DA HABILIDADE
        self.efeito = efeito # EFEITO QUE HABILIDADE APLICA SOBRE O PRÓPIO JOGADOR
        self.nível_mínimo = nível_mínimo # NÍVEL MÍNIMO PARA USAR A HABILIDADE
        self.aplicar = None # VERIFICA SE A HABILIDADE PODE SER APLICADA OU NÃO

    def verificar_nível(self): # VERIFICA SE O JOGADOR TEM NÍVEL SUFICIENTE PARA USAR A HABILIDADE
        if jogador["nível"] >= self.nível_mínimo:
            self.aplicar = True
        else: 
            self.aplicar = False

    def aplicar_habilidade(self): # APLICA A HABILIDADE SE O JOGADOR TIVER NÍVEL SUFICIENTE
        if self.aplicar == True:
            self.efeito(jogador)
        else:
            pass

# HABILIDADES PASSIVAS CLASSSE: ASSASSINO

def efeito_furtividade():
    jogador["dano"] *= 1.25
    jogador["velocidade"] *= 1.25
    jogador["defesa"] *= 0.75
    jogador["estamina"] *= 0.75
    jogador["vida"] *= 1.25
furtividade = HabilidadePassiva("furtividade", efeito_furtividade, 12)

def efeito_evasão():
    jogador["velocidade"] *= 1.5
    jogador["defesa"] *= 1.5
    jogador["estamina"] *= 1.5
    jogador["vida"] *= 1.5
evasão = HabilidadePassiva("evsão", efeito_evasão, 45)

def efeito_sangramento():
    jogador["dano"] *= 2
    jogador["vida"] *= 0.8
sangramento = HabilidadePassiva("sangramento", efeito_sangramento, 70)

# HABILIDADES PASSIVAS CLASSE: ESPADACHIN

def efeito_vontade_da_espada():
    jogador["dano"] *= 1.2
    jogador["velocidade"] *= 1.2
    jogador["defesa"] *= 1.2
    jogador["estamina"] *= 1.2
    jogador["vida"] *= 1.2
vontade_da_espada = HabilidadePassiva("vontade da espada", efeito_vontade_da_espada, 12)

def efeito_herança_da_espada():
    jogador["dano"] *= 1.45
    jogador["velocidade"] *= 1.45
    jogador["defesa"] *= 1.45
    jogador["estamina"] *= 1.45
    jogador["vida"] *= 1.45
herança_da_espada = HabilidadePassiva("herança da espada", efeito_herança_da_espada, 45)

def efeito_ataque_rápido():
    jogador["dano"] *= 1.85
    jogador["velocidade"] *= 1.85
    jogador["defesa"] *= 0.7
    jogador["estamina"] *= 0.9
ataque_rapido = HabilidadePassiva("ataque rápido", efeito_ataque_rápido, 70)

# HABILIDADES PASSIVAS CLASSE: ESCUDEIRO

def efeito_bloqueio_de_ataque():
    jogador["defesa"] *= 2
    jogador["estamina"] *= 1.75
    jogador["vida"] *= 1.1
bloqueio_de_ataque = HabilidadePassiva("bloqueio de ataque", efeito_bloqueio_de_ataque, 12)

def efeito_repelir(adversário):
    dano = (adversário["dano"] * 0.75)
    adversário["defesa"] *= 0.5
    adversário["vida"] -= dano
repelir = HabilidadePassiva("repelir", efeito_repelir, 45)

def efeito_peso_pena():
    jogador["velocidade"] *= 1.5
    jogador["estamina"] *= 1.5
    jogador["vida"] *= 1.5
peso_pena = HabilidadePassiva("peso pena", efeito_peso_pena, 70)

# HABILIDADES PASSIVAS CLASSE: LANÇEIRO

def efeito_dança_da_lança():
    jogador["estamina"] *= 1.3
    jogador["velocidade"] *= 1.3
dança_da_lança = HabilidadePassiva("dança da lança", efeito_dança_da_lança, 12)

def efeito_controle_passivo():
    jogador["estamina"] *= 1.2
    jogador["defesa"] *= 1.5
    jogador["velocidade"] *= 1.2
    jogador["dano"] *= 1.5
    jogador["vida"] *= 1.5
controle_passivo = HabilidadePassiva("controle passivo", efeito_controle_passivo, 45)

def efeito_controle_total():
    jogador["estamina"] *= 1.35
    jogador["defesa"] *= 1.35
    jogador["velocidade"] *= 1.35
    jogador["dano"] *= 1.35
    jogador["vida"] *= 1.35
controle_total = HabilidadePassiva("controle total", efeito_controle_total, 70)

# HABILIDADES PASSIVAS CLASSE: ARQUEIRO

def efeito_disparo_preciso():
    jogador["dano"] *= 1.25
    jogador["velocidade"] *= 0.75
    jogador["defesa"] *= 0.75
disparo_preciso = HabilidadePassiva("disparo preciso", efeito_disparo_preciso, 12)

def efeito_passos_silenciosos():
    jogador["velocidade"] *= 1.4
    jogador["estamina"] *= 1.4
    jogador["vida"] *= 1.4
    jogador["defesa"] *= 0.6
passos_silenciosos = HabilidadePassiva("passos silenciosos", efeito_passos_silenciosos, 45)

def efeito_flecha_dupla():
    jogador["dano"] *= 1.75
    jogador["velocidade"] *= 0.8
    jogador["defesa"] *= 0.8
flecha_dupla = HabilidadePassiva("flecha dupla", efeito_flecha_dupla, 70)
    
# HABILIDADES PASSIVAS CLASSE: BATEDOR

def efeito_ataque_silencioso():
    jogador["velocidade"] *= 1.8
    jogador["defesa"] *= 0.85
    jogador["dano"] *= 1.3
ataque_silencioso = HabilidadePassiva("ataque silencioso", efeito_ataque_silencioso, 12)

def efeito_evasão_rápida():
    jogador["velocidade"] *= 1.5
    jogador["defesa"] *= 1.2
    jogador["estamina"] *= 0.7
    jogador["vida"] *= 1.5
evasao_rapida = HabilidadePassiva("evasão rápida", efeito_evasão_rápida, 45)

def efeito_exploracao_furtiva():
    jogador["velocidade"] *= 1.3
    jogador["dano"] *= 1.2
    jogador["defesa"] *= 1.1
    jogador["estamina"] *= 0.9
    jogador["vida"] *= 1.3
exploracao_furtiva = HabilidadePassiva("Exploração furtiva", efeito_exploracao_furtiva, 70)