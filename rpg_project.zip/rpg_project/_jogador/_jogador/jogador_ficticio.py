jogador = {
    "nível": 78,
    "vida": 100,
    "dano": 20,
    "velocidade": 15,
    "defesa": 5,
    "arma": None,
    "estamina": 100,
}
