import random
# JOGADOR FICTÍCIO

from _jogador._jogador.check_jogador_ficticio import jogador

# CLASSE CONJUNTO DE ARMADURA

class ConjuntoArmadura:
    def __init__(self, NomeCojunto):
        self.armaduras = []
        self.NomeCojunto = NomeCojunto
        self.ConjuntoCompleto = None  
        self.peças = ["elmo", "peitoral", "calça", "bota"]
        self.TiposConjunto = ["ataque", "defesa"]
        self.TipoConjunto = ""
        self.bonus = False

    def VerificarSeOconjuntoEstáCompleto(self):
        if len(self.armaduras) == 4:
            self.ConjuntoCompleto = True

        if self.ConjuntoCompleto == True:  
             self.bonus = True

    def AplicarBonusConjunto(self):
        if self.bonus == True:
            if self.TipoConjunto == "ataque":
                jogador["dano"] *= 1.8
                jogador["defesa"] *= 1.6
                jogador["velocidade"] *= 1.4
                jogador["vida"] *= 1.2

        if self.bonus == True:
            if self.TipoConjunto == "defesa":
                jogador["dano"] *= 1.6
                jogador["defesa"] *= 1.4
                jogador["velocidade"] *= 1.2
                jogador["vida"] *= 1.2

# CLASSE PEÇA INDIVIDUAL

class PeçaArmadura:
    def __init__(self, peça, tipo, defesa, material, efeito_individual):
        self.peça = peça
        self.tipos = ["defesa", "ataque"]
        self.tipo = tipo
        self.defesa = defesa
        self.material = material
        self.efeitos = ["dano", "velocidade", "vida", "defesa", "bonus_experiencia"]
        self.efeito_individual = efeito_individual
        self.equipada = False
        self.raridades = ["comum", "raro", "épico", "lendário"]
        self.raridade = ""

    def equipar(self):
        if not self.equipada:
            jogador["defesa"] += self.defesa
            self.equipada = True

    def escolher_raridade(self, raridade):
        self.raridade = raridade

    def aplicar_efeito_aleatorio(self):
        dano = 4
        velocidade = 2 
        vida = 10
        defesa = 3
        bonus_experiencia = 5

        if self.raridade == "rara":
            dano = 6
            velocidade = 3
            vida = 15
            defesa = 5
            bonus_experiencia = 10

        elif self.raridade == "épico":
            dano = 8
            velocidade = 4
            vida = 20
            defesa = 7
            bonus_experiencia = 15

        elif self.raridade == "lendário":
            dano = 10
            velocidade = 5
            vida = 25
            defesa = 10
            bonus_experiencia = 20


        if self.equipada is not None or False:
            efeito = random.choice(self.efeitos)
            if efeito == "dano":
                jogador["dano"] += dano

            elif efeito == "velocidade":
                jogador["velocidade"] += velocidade

            elif efeito == "vida":
                jogador["vida"] += vida

            elif efeito == "defesa":
                jogador["defesa"] += defesa

            elif efeito == "bonus_experiencia":
                jogador["experiencia"] += bonus_experiencia

    def escolher_efeito(self, efeito):
        self.efeito_individual = efeito
        if efeito in self.efeitos:
            dano = 4
            velocidade = 2 
            vida = 10
            defesa = 3
            bonus_experiencia = 5

            if self.raridade == "rara":
                dano = 6
                velocidade = 3
                vida = 15
                defesa = 5
                bonus_experiencia = 10

            elif self.raridade == "épico":
                dano = 8
                velocidade = 4
                vida = 20
                defesa = 7
                bonus_experiencia = 15

            elif self.raridade == "lendário":
                dano = 10
                velocidade = 5
                vida = 25
                defesa = 10
                bonus_experiencia = 20


            if self.equipada is not None or False:
                if self.efeito_individual == "dano":
                    jogador["dano"] += dano

                elif self.efeito_individual == "velocidade":
                    jogador["velocidade"] += velocidade

                elif self.efeito_individual == "vida":
                    jogador["vida"] += vida

                elif self.efeito_individual == "defesa":
                    jogador["defesa"] += defesa

                elif self.efeito_individual == "bonus_experiencia":
                    jogador["experiencia"] += bonus_experiencia

    def AdicioanarPeçaAoCojunto(self, peça):
        ConjuntoArmadura.armaduras.append(peça)
        self.VerificarSeOconjuntoEstáCompleto()

def ElmocComum():
    elmo = PeçaArmadura("Elmo Comum", "elmo", 5, "ferro", None)


# Criando peças de armadura
elmo = PeçaArmadura("Elmo de Ferro", "elmo", 5, "ferro", efeito_elmo)
peitoral = PeçaArmadura("Peitoral de Ferro", "peitoral", 10, "ferro", efeito_peitoral)
botas = PeçaArmadura("Botas de Ferro", "botas", 3, "ferro", None)  # Sem efeito adicional
luvas = PeçaArmadura("Luvas de Ferro", "luvas", 2, "ferro", None)

# Criando o conjunto de armadura
conjunto_ferramenta = ConjuntoArmadura("Conjunto de Ferro")

# Equipando as peças ao conjunto
conjunto_ferramenta.adicionar_peca(elmo)
conjunto_ferramenta.adicionar_peca(peitoral)
conjunto_ferramenta.adicionar_peca(botas)
conjunto_ferramenta.adicionar_peca(luvas)

# Equipando o conjunto completo
conjunto_ferramenta.equipar_conjunto()

# Exibindo o estado do jogador após equipar o conjunto
print(f"Vida do Jogador: {jogador['vida']}")
print(f"Dano do Jogador: {jogador['dano']}")
print(f"Velocidade do Jogador: {jogador['velocidade']}")
print(f"Defesa do Jogador: {jogador['defesa']}")
