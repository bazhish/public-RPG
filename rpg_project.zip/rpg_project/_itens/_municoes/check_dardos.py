from random import choice, randint
from typing import Optional, Dict, Any
from _itens._check_efeitos_das_municoes.check_efeitos_dardos import (
    Veneno, Assoviante, Flamejante, Explosiva, Paralisante, Tranquilizante
)

class Dardo:
    raridades = {
        "comum": 1.0,
        "rara": 1.5,
        "épica": 2.3,
        "lendaria": 2.8
    }
    
    efeitos_possiveis = [Veneno, Assoviante, Flamejante, Explosiva, Paralisante, Tranquilizante]

    def __init__(self, dano_base: int, peso: int):
        self.dano_base = dano_base
        self.peso = peso
        self.nivel = 1
        self.raridade = ""
        self.efeito: Optional[Any] = None
        self.dano_calculado: float = dano_base

    def definir_nivel_com_parametro_usuario(self, usuario) -> None:
        nivel_usuario = usuario["nível"]
        self.nivel = randint(max(1, nivel_usuario - 3), min(nivel_usuario + 3, 100))

    def definir_nivel_manual(self, nivel: int) -> None:
        self.nivel = nivel

    def calcular_dano(self) -> None:
        fator = self.raridades.get(self.raridade, 1)
        self.dano_calculado = self.dano_base * self.nivel * fator

    def escolher_raridade(self, raridade: str) -> None:
        self.raridade = raridade

    def escolher_efeito_aleatorio(self) -> None:
        self.efeito = choice(self.efeitos_possiveis)

    def escolher_efeito_manual(self, efeito: Any) -> None:
        self.efeito = efeito

    def gerar_dardo(self) -> Dict[str, Any]:
        self.calcular_dano()
        return {
            "Dano": self.dano_calculado,
            "Peso": self.peso,
            "Nível": self.nivel,
            "Raridade": self.raridade,
            "Efeito": self.efeito,
        }

def criar_dardo(tipo, raridade, usuario = None):
    dardo_automatico = {
        "dardo": {"comum": (5,1), "raro": (7,1), "epico": (10,1), "lendario": (12,1)}
    }

    if tipo in dardo_automatico and raridade in dardo_automatico[tipo]:
        dano, peso = dardo_automatico[tipo][raridade]
        dardo = Dardo(dano, peso)
        dardo.escolher_raridade(raridade)

        if usuario:
            dardo.definir_nivel_com_parametro_usuario(usuario)
            dardo.escolher_efeito_aleatorio()

        dardo.gerar_dardo()
    return dardo
