from random import choice, randint
from _itens._check_efeitos_das_municoes.check_efeitos_flecha import Veneno, Assoviante, Flamejante, Explosiva, Paralisante
from _jogador._jogador.check_jogador_ficticio import jogador

class Flecha:
    raridades = ["comum", "rara", "épica", "lendaria"]
    efeitos_possiveis = [Veneno, Assoviante, Flamejante, Explosiva, Paralisante]
    fatores_raridade = {
        "comum": 1.0,
        "rara": 1.5,
        "épica": 2.3,
        "lendaria": 2.8
    }

    def __init__(self, dano_base: float, peso: float):
        self.dano_base = dano_base
        self.peso = peso
        self.nivel = 1
        self.raridade = "comum"
        self.efeito = None
        self.dano_final = dano_base

    def definir_nivel_com_parametro_jogador(self):
        nivel_jogador = jogador["nível"]
        self.nivel = randint(max(1, nivel_jogador - 3), min(nivel_jogador + 3, 100))

    def definir_nivel_manual(self, nivel: int):
        if nivel < 1 or nivel > 100:
            raise ValueError("Nível deve estar entre 1 e 100.")
        self.nivel = nivel

    def escolher_raridade(self, raridade: str):
        if raridade in self.raridades:
            self.raridade = raridade
        else:
            print(f"Raridade inválida: {raridade}. Mantendo 'comum'.")
            self.raridade = "comum"

    def escolher_efeito_aleatorio(self):
        self.efeito = choice(self.efeitos_possiveis)

    def escolher_efeito_manual(self, efeito):
        if efeito in self.efeitos_possiveis:
            self.efeito = efeito
        else:
            print("Efeito inválido.")
            self.efeito = None

    def calcular_dano(self):
        fator = self.fatores_raridade.get(self.raridade, 1.0)
        self.dano_final = self.dano_base * self.nivel * fator

    def gerar_dict(self):
        self.calcular_dano()
        return {
            "Dano": self.dano_final,
            "Peso": self.peso,
            "Nível": self.nivel,
            "Raridade": self.raridade,
            "Efeito": self.efeito,
        }

    def __repr__(self):
        return (f"<Flecha nivel={self.nivel} raridade='{self.raridade}' "
                f"dano={self.dano_final:.1f} efeito='{self.efeito.nome if self.efeito else 'Nenhum'}'>")

# Funções fábricas para flechas comuns e flechas duplas

def flecha_comum():
    f = Flecha(5, 1)
    f.escolher_raridade("comum")
    f.definir_nivel_com_parametro_jogador()
    f.escolher_efeito_aleatorio()
    return f

def flecha_rara():
    f = Flecha(7, 1)
    f.escolher_raridade("rara")
    f.definir_nivel_com_parametro_jogador()
    f.escolher_efeito_aleatorio()
    return f

def flecha_epica():
    f = Flecha(9, 1)
    f.escolher_raridade("épica")
    f.definir_nivel_com_parametro_jogador()
    f.escolher_efeito_aleatorio()
    return f

def flecha_lendaria():
    f = Flecha(13, 1)
    f.escolher_raridade("lendaria")
    f.definir_nivel_com_parametro_jogador()
    f.escolher_efeito_aleatorio()
    return f

def flecha_dupla_comum():
    f = Flecha(6, 1)
    f.escolher_raridade("comum")
    f.definir_nivel_com_parametro_jogador()
    f.escolher_efeito_aleatorio()
    return f

def flecha_dupla_rara():
    f = Flecha(8, 1)
    f.escolher_raridade("rara")
    f.definir_nivel_com_parametro_jogador()
    f.escolher_efeito_aleatorio()
    return f

def flecha_dupla_epica():
    f = Flecha(10, 1)
    f.escolher_raridade("épica")
    f.definir_nivel_com_parametro_jogador()
    f.escolher_efeito_aleatorio()
    return f

def flecha_dupla_lendaria():
    f = Flecha(15, 1)
    f.escolher_raridade("lendaria")
    f.definir_nivel_com_parametro_jogador()
    f.escolher_efeito_aleatorio()
    return f
