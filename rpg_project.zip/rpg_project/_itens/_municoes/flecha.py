from _efeitos_das_municoes.efeitos_flecha import veneno, assoviante, flamejante, explosiva, paralisante
from random import randint, choice

# JOGADOR FICTICIO

from _jogador._jogador.jogador_ficticio import jogador

# CLASSE

class Flecha:
    def __init__(self, dano, peso):
        self.flecha = {}
        self.dano = dano
        self.peso = peso
        self.nível = 1
        self.raridades = ["comum", "rara", "épica", "lendaria"]
        self.raridade = ""
        self.efeitos = [veneno, assoviante, flamejante, explosiva, paralisante]
        self.efeito = ""

    def NívelComParametroJogador(self):
        nível = jogador["nível"]
        self.nível = randint(max(0, nível - 3), min(nível + 3, 100))

    def NivelComParamentroManual(self, nível):
        self.nível = nível

    def DanoDaFlecha(self):
        self.dano = self.dano * self.nível

    def EscolherRaridade(self, RaridadeEscolhida):
        if RaridadeEscolhida in self.raridades:
            self.raridade = RaridadeEscolhida

        else:
            print("Raridade inválida.")

    
    def EfeitoAleatorio(self):
        self.efeito = choice(self.efeitos)

    def EfeitoManual(self, efeito):
        if efeito in self.efeitos:
            self.efeito = efeito
        else:
            print("Efeito inválido.")

        return self.efeito
    
    def ClasseDaFlecha(self):
        self.flecha = {
            "Dano": self.dano,
            "Peso": self.peso,
            "Nível": self.nível,
            "Raridade": self.raridade,
        }

        if self.raridade == "rara":
            self.flecha["Dano"] *= 1.5

        elif self.raridade == "épica":
            self.flecha["Dano"] *= 2.3

        elif self.raridade == "lendaria":
            self.flecha["Dano"] *= 2.8

        return self.flecha
    
# FLECHAS

def FlechaComum():
    flecha = Flecha(5,1)
    flecha.EscolherRaridade("comum")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

def FlechaRara():
    flecha = Flecha(7,1)
    flecha.EscolherRaridade("rara")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

def FlechaEpica():
    flecha = Flecha(9,1)
    flecha.EscolherRaridade("épica")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

def FlechaLendaria():
    flecha = Flecha(13,1)
    flecha.EscolherRaridade("lendaria")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

# FLECHAS DUPLAS

def FlechaDuplaComum():
    flecha = Flecha(6, 1)
    flecha.EscolherRaridade("comum")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

def FlechaDuplaRara():
    flecha = Flecha(8, 1)
    flecha.EscolherRaridade("rara")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

def FlechaDuplaEpica():
    flecha = Flecha(10,1)
    flecha.EscolherRaridade("épica")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha

def FlechaDuplaLendaria():
    flecha = Flecha(15,1)
    flecha.EscolherRaridade("lendaria")
    flecha.NívelComParametroJogador()
    flecha.DanoDaFlecha()
    flecha.EfeitoAleatorio()
    flecha.ClasseDaFlecha()
    return flecha