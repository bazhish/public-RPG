from time import sleep

def efeito_paralisante(duração):
    for x in range(duração):
        sleep(1.5)
        velocidade -= 2
    return velocidade

def veneno_efeito(duração):
    for x in range(duração):
        sleep(1.5)
        dano = 3
    return dano

def efeito_flamejante(duração):
    for x in range(duração):
        sleep(1.5)
        dano = 6
    return dano

class EfeitoDardo:
    def __init__(self, nome, dano, tipo, alcance, duracao):
        self.nome = nome
        self.dano = dano
        self.tipo = tipo
        self.alcance = alcance
        self.duracao = duracao

class Veneno(EfeitoDardo):
    def __init__(self):
        super().__init__("Veneno", veneno_efeito(3), "Dano ao longo do tempo", 5, 3)

class Assoviante(EfeitoDardo):
    def __init__(self):
        super().__init__("Assoviante", 0, "Atração de inimigos", 15, 0)

class Flamejante(EfeitoDardo):
    def __init__(self):
        super().__init__("Flamejante", efeito_flamejante(4), "Dano de fogo", 20, 2)

class Explosiva(EfeitoDardo):
    def __init__(self):
        super().__init__("Explosiva", 12, "Dano em área", 12, 1)

class Paralisante(EfeitoDardo):
    def __init__(self):
        super().__init__("Paralisante", 0, "Imobilização temporária", 6, 4)
        
class Tranquilizante(EfeitoDardo):
    def __init__(self):
        super().__init__("Tranquilizante", efeito_paralisante(4), "Redução de velocidade", 5, 5)

veneno = Veneno()
assoviante = Assoviante()
flamejante = Flamejante()
explosiva = Explosiva()
paralisante = Paralisante()
tranquilizante = Tranquilizante()