from random import choice, randint, uniform

# JOGADOR FICTICIO

from _jogador._jogador.jogador_ficticio import jogador

# CLASSE

class Arma:
    def __init__(self, nome, dano, peso):
        self.arma = {}
        self.nome = nome
        self.raridades = ["comum", "rara", "épica", "lendaria"]
        self.raridade = ""
        self.dano = dano
        self.bonus = uniform(1.1, 1.9)
        self.peso = peso
        self.atributos = ["dano", "vida", "velocidade", "defesa"]
        self.atributo = ""
        self.nível = 1

    def NívelComParametroJogador(self):
        nível = jogador["nível"]
        self.nível = randint(max(0, nível - 3), min(nível + 3, 100))

    def NivelComParamentroManual(self, nível):
        self.nível = nível

    def DanoDaArma(self):
        self.dano = self.dano * self.nível

    def VelocidadeQueOplayerIraPerder(self):
        if jogador["arma"] is not None:
            jogador["velocidade"] -= self.peso

    def EscolherRaridade(self, RaridadeEscolhida):
        if RaridadeEscolhida in self.raridades:
            self.raridade = RaridadeEscolhida

        else:
            print("Raridade inválida.")

    def AtributoAdicionalAleatorio(self):
        dano = 2
        vida = 10
        velocidade = 3
        defesa = 1

        if self.raridade == "rara":
            dano *= 1.5
            vida *= 1.5
            velocidade *= 1.5
            defesa *= 1.5

        elif self.raridade == "épica":
            dano *= 2.3
            vida *= 2.3
            velocidade *= 2.3
            defesa *= 2.3

        elif self.raridade == "lendaria":
            dano *= 2.8
            vida *= 2.8
            velocidade *= 2.8
            defesa *= 2.8

        self.AtributoEscolhido = choice(self.atributos)

        if self.AtributoEscolhido == "dano":
            jogador["dano"] += dano * self.nível

        elif self.AtributoEscolhido == "vida":
            jogador["vida"] += vida * self.nível

        elif self.AtributoEscolhido == "velocidade":
            jogador["velocidade"] += velocidade * self.nível

        elif self.AtributoEscolhido == "defesa":
            jogador["defesa"] += defesa * self.nível

    def AtributoAdicionalManual(self, atributo):
        dano = 2
        vida = 10
        velocidade = 3
        defesa = 1

        if self.raridade == "rara":
            dano *= 1.5
            vida *= 1.5
            velocidade *= 1.5
            defesa *= 1.5

        elif self.raridade == "épica":
            dano *= 2.3
            vida *= 2.3
            velocidade *= 2.3
            defesa *= 2.3

        elif self.raridade == "lendaria":
            dano *= 2.8
            vida *= 2.8
            velocidade *= 2.8
            defesa *= 2.8


        if atributo in self.atributos:
            self.AtributoEscolhido = atributo

            if self.AtributoEscolhido == "dano":
                jogador["dano"] += (dano * self.nível)

            elif self.AtributoEscolhido == "vida":
                jogador["vida"] += (vida * self.nível)

            elif self.AtributoEscolhido == "velocidade":
                jogador["velocidade"] += (velocidade * self.nível)

            elif self.AtributoEscolhido == "defesa":
                jogador["defesa"] += (defesa * self.nível)

        else:
            print("Atributo inválido.")

    def ClasseDaArma(self):
          
        self.arma = {
                "Arma": self.nome,
                "Raridade":self.raridade,
                "Nível": self.nível,
                "Dano": self.dano,
                "Bonus de experiência": self.bonus,
                "Peso": self.peso,
                "Atributo adicional": self.AtributoEscolhido,
            }

        if self.raridade == "rara":
                self.arma["Dano"] *= 1.5
                self.arma["Bonus de experiência"] *= 1.5

        elif self.raridade == "épica":
                self.arma["Dano"] *= 2.3
                self.arma["Bonus de experiência"] *= 2.3

        elif self.raridade == "lendaria":
                self.arma["Dano"] *= 2.8
                self.arma["Bonus de experiência"] *= 2.8

        return self.arma

# ESPADAS

def EspadaComum():
    espada = Arma("Espada", 6, 3)
    espada.EscolherRaridade("comum")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

def EspadaRara():
    espada = Arma("Espada", 11, 3)
    espada.EscolherRaridade("rara")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

def EspadaEpica():
    espada = Arma("Espada", 18, 2)
    espada.EscolherRaridade("épica")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

def EspadaLendaria(): 
    espada = Arma("Espada", 23, 2)
    espada.EscolherRaridade("lendaria")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

# ESPADA CURTA

def EspadaCurtaComum():
    espada = Arma("Espada Curta", 6, 2)
    espada.EscolherRaridade("comum")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

def EspadaCurtaRara():
    espada = Arma("Espada Curta", 8, 2)
    espada.EscolherRaridade("rara")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

def EspadaCurtaEpica():
    espada = Arma("Espada Curta", 12, 1)
    espada.EscolherRaridade("épica")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

def EspadaCurtaLendaria():
    espada = Arma("Espada Curta", 18, 1)
    espada.EscolherRaridade("lendaria")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

# ESPADA LONGA

def EspadaLongaComum():
    espada = Arma("Espada Longa", 9, 4)
    espada.EscolherRaridade("comum")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

def EspadaLongaRara():
    espada = Arma("Espada Longa", 12, 4)
    espada.EscolherRaridade("rara")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

def EspadaLongaEpica():
    espada = Arma("Espada Longa", 16, 3)
    espada.EscolherRaridade("épica")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

def EspadaLongaLendaria():
    espada = Arma("Espada Longa", 24, 3)
    espada.EscolherRaridade("lendaria")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

# ESPADA DUPLA

def EspadaDuplaComum():
    espada = Arma("Espada Dupla", 10, 5)
    espada.EscolherRaridade("comum")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

def EspadaDuplaRara():
    espada = Arma("Espada Dupla", 14, 5)
    espada.EscolherRaridade("rara")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

def EspadaDuplaÉpica():
    espada = Arma("Espada dupla", 18, 3)
    espada.EscolherRaridade("épica")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

def EspadaDuplaLendaria():
    espada = Arma("Espada dupla", 21, 3)
    espada.EscolherRaridade("lendaria")
    espada.NívelComParametroJogador()
    espada.DanoDaArma()
    espada.AtributoAdicionalAleatorio()
    espada.ClasseDaArma()
    return espada

# ADAGAS

def AdagaComum():
    adaga = Arma("Adaga", 5, 3)
    adaga.EscolherRaridade("comum")
    adaga.NívelComParametroJogador()
    adaga.DanoDaArma()
    adaga.AtributoAdicionalAleatorio()
    adaga.ClasseDaArma()
    return adaga

def AdagaRara():
    adaga = Arma("Adaga", 8, 3)
    adaga.EscolherRaridade("rara")
    adaga.NívelComParametroJogador()
    adaga.DanoDaArma()
    adaga.AtributoAdicionalAleatorio()
    adaga.ClasseDaArma()
    return adaga

def AdagaEpica():
    adaga = Arma("Adaga", 10, 2)
    adaga.EscolherRaridade("épica")
    adaga.NívelComParametroJogador()
    adaga.DanoDaArma()
    adaga.AtributoAdicionalAleatorio()
    adaga.ClasseDaArma()
    return adaga

def AdagaLendaria():
    adaga = Arma("Adaga",13, 2)
    adaga.EscolherRaridade("lendaria")
    adaga.NívelComParametroJogador()
    adaga.DanoDaArma()
    adaga.AtributoAdicionalAleatorio()
    adaga.ClasseDaArma()
    return adaga

# ADAGAS DUPLAS

def AdagaDuplaComum():
    adaga = Arma("Adaga dupla", 7, 5)
    adaga.EscolherRaridade("comum")
    adaga.NívelComParametroJogador()
    adaga.DanoDaArma()
    adaga.AtributoAdicionalAleatorio()
    adaga.ClasseDaArma()
    return adaga

def AdagaDuplaRara():
    adaga = Arma("Adaga dupla", 16, 5)
    adaga.EscolherRaridade("rara")
    adaga.NívelComParametroJogador()
    adaga.DanoDaArma()
    adaga.AtributoAdicionalAleatorio()
    adaga.ClasseDaArma()
    return adaga

def AdagaDuplaÉpica():
    adaga = Arma("Adaga dupla", 20, 4)
    adaga.EscolherRaridade("épica")
    adaga.NívelComParametroJogador()
    adaga.DanoDaArma()
    adaga.AtributoAdicionalAleatorio()
    adaga.ClasseDaArma()
    return adaga

def AdagaDuplaLendaria():
    adaga = Arma("Adaga dupla", 26, 4)
    adaga.EscolherRaridade("lendaria")
    adaga.NívelComParametroJogador()
    adaga.DanoDaArma()
    adaga.AtributoAdicionalAleatorio()
    adaga.ClasseDaArma()
    return adaga

# ZARABATANA

def ZarabatanaComum():
    zarabatana = Arma("zarabatana", 4, 3)
    zarabatana.EscolherRaridade("comum")
    zarabatana.NívelComParametroJogador()
    zarabatana.DanoDaArma()
    zarabatana.AtributoAdicionalAleatorio()
    zarabatana.ClasseDaArma()
    return zarabatana

def ZarabatanaRara():
    zarabatana = Arma("zarabatana", 6, 3)
    zarabatana.EscolherRaridade("rara")
    zarabatana.NívelComParametroJogador()
    zarabatana.DanoDaArma()
    zarabatana.AtributoAdicionalAleatorio()
    zarabatana.ClasseDaArma()
    return zarabatana

def ZarabatanaÉpica():
    zarabatana = Arma("zarabatana", 8, 2)
    zarabatana.EscolherRaridade("épica")
    zarabatana.NívelComParametroJogador()
    zarabatana.DanoDaArma()
    zarabatana.AtributoAdicionalAleatorio()
    zarabatana.ClasseDaArma()
    return zarabatana

def ZarabatanaLendaria():
    zarabatana = Arma("zarabatana", 13, 2)
    zarabatana.EscolherRaridade("lendaria")
    zarabatana.NívelComParametroJogador()
    zarabatana.DanoDaArma()
    zarabatana.AtributoAdicionalAleatorio()
    zarabatana.ClasseDaArma()
    return zarabatana

# BESTA

def BestaComum():
    besta = Arma("besta", 6, 5)
    besta.EscolherRaridade("comum")
    besta.NívelComParametroJogador()
    besta.DanoDaArma()
    besta.AtributoAdicionalAleatorio()
    besta.ClasseDaArma()
    return besta

def BestaRara():
    besta = Arma("besta", 9, 5)
    besta.EscolherRaridade("rara")
    besta.NívelComParametroJogador()
    besta.DanoDaArma()
    besta.AtributoAdicionalAleatorio()
    besta.ClasseDaArma()
    return besta

def BestaÉpica():
    besta = Arma("besta", 12, 4)
    besta.EscolherRaridade("épica")
    besta.NívelComParametroJogador()
    besta.DanoDaArma()
    besta.AtributoAdicionalAleatorio()
    besta.ClasseDaArma()
    return besta

def BestaLendaria():
    besta = Arma("besta", 16, 4)
    besta.EscolherRaridade("lendaria")
    besta.NívelComParametroJogador()
    besta.DanoDaArma()
    besta.AtributoAdicionalAleatorio()
    besta.ClasseDaArma()
    return besta

# ARCO

def ArcoComum():
    arco = Arma("arco", 5, 3)
    arco.EscolherRaridade("comum")
    arco.NívelComParametroJogador()
    arco.DanoDaArma()
    arco.AtributoAdicionalAleatorio()
    arco.ClasseDaArma()
    return arco

def ArcoRara():
    arco = Arma("arco", 8, 3)
    arco.EscolherRaridade("rara")
    arco.NívelComParametroJogador()
    arco.DanoDaArma()
    arco.AtributoAdicionalAleatorio()
    arco.ClasseDaArma()
    return arco

def ArcoÉpica():
    arco = Arma("arco", 10, 2)
    arco.EscolherRaridade("épica")
    arco.NívelComParametroJogador()
    arco.DanoDaArma()
    arco.AtributoAdicionalAleatorio()
    arco.ClasseDaArma()
    return arco

def ArcoLendaria():
    arco = Arma("arco", 16, 2)
    arco.EscolherRaridade("lendaria")
    arco.NívelComParametroJogador()
    arco.DanoDaArma()
    arco.AtributoAdicionalAleatorio()
    arco.ClasseDaArma()
    return arco

# LANÇA

def LancaComum():
    lança = Arma("lança", 6, 4)
    lança.EscolherRaridade("comum")
    lança.NívelComParametroJogador()
    lança.DanoDaArma()
    lança.AtributoAdicionalAleatorio()
    lança.ClasseDaArma()
    return lança

def LancaRara():
    lança = Arma("lança", 8, 4)
    lança.EscolherRaridade("rara")
    lança.NívelComParametroJogador()
    lança.DanoDaArma()
    lança.AtributoAdicionalAleatorio()
    lança.ClasseDaArma()
    return lança

def LancaÉpica():
    lança = Arma("lança", 11, 3)
    lança.EscolherRaridade("épica")
    lança.NívelComParametroJogador()
    lança.DanoDaArma()
    lança.AtributoAdicionalAleatorio()
    lança.ClasseDaArma()
    return lança

def LancaLendaria():
    lança = Arma("lança", 16, 5)
    lança.EscolherRaridade("lendaria")
    lança.NívelComParametroJogador()
    lança.DanoDaArma()
    lança.AtributoAdicionalAleatorio()
    lança.ClasseDaArma()
    return lança

# MACHADOS

def MachadoComum():
    machado = Arma("machado", 8, 4)
    machado.EscolherRaridade("comum")
    machado.NívelComParametroJogador()
    machado.DanoDaArma()
    machado.AtributoAdicionalAleatorio()
    machado.ClasseDaArma()
    return machado

def MachadoRara():
    machado = Arma("machado", 10, 4)
    machado.EscolherRaridade("rara")
    machado.NívelComParametroJogador()
    machado.DanoDaArma()
    machado.AtributoAdicionalAleatorio()
    machado.ClasseDaArma()
    return machado

def MachadoÉpica():
    machado = Arma("machado", 16, 4)
    machado.EscolherRaridade("épica")
    machado.NívelComParametroJogador()
    machado.DanoDaArma()
    machado.AtributoAdicionalAleatorio()
    machado.ClasseDaArma()
    return machado

def MachadoLendaria():
    machado = Arma("machado", 20, 4)
    machado.EscolherRaridade("lendaria")
    machado.NívelComParametroJogador()
    machado.DanoDaArma()
    machado.AtributoAdicionalAleatorio()
    machado.ClasseDaArma()
    return machado

# MACHADO DUPLO

def MachadoDuploComum():
    machado = Arma("machado duplo", 10, 6)
    machado.EscolherRaridade("comum")
    machado.NívelComParametroJogador()
    machado.DanoDaArma()
    machado.AtributoAdicionalAleatorio()
    machado.ClasseDaArma()
    return machado

def MachadoDuploRara():
    machado = Arma("machado duplo", 18, 6)
    machado.EscolherRaridade("rara")
    machado.NívelComParametroJogador()
    machado.DanoDaArma()
    machado.AtributoAdicionalAleatorio()
    machado.ClasseDaArma()
    return machado

def MachadoDuploÉpica():
    machado = Arma("machado duplo", 24, 6)
    machado.EscolherRaridade("épica")
    machado.NívelComParametroJogador()
    machado.DanoDaArma()
    machado.AtributoAdicionalAleatorio()
    machado.ClasseDaArma()
    return machado

def MachadoDuploLendaria():
    machado = Arma("machado duplo", 26, 5)
    machado.EscolherRaridade("lendaria")
    machado.NívelComParametroJogador()
    machado.DanoDaArma()
    machado.AtributoAdicionalAleatorio()
    machado.ClasseDaArma()
    return machado

#  CUTELO

def CuteloComum():
    cutelo = Arma("cutelo", 9, 4)
    cutelo.EscolherRaridade("comum")
    cutelo.NívelComParametroJogador()
    cutelo.DanoDaArma()
    cutelo.AtributoAdicionalAleatorio()
    cutelo.ClasseDaArma()
    return cutelo

def CuteloRara():
    cutelo = Arma("cutelo", 12, 4)
    cutelo.EscolherRaridade("rara")
    cutelo.NívelComParametroJogador()
    cutelo.DanoDaArma()
    cutelo.AtributoAdicionalAleatorio()
    cutelo.ClasseDaArma()
    return cutelo

def CuteloÉpica():
    cutelo = Arma("cutelo", 15, 3)
    cutelo.EscolherRaridade("épica")
    cutelo.NívelComParametroJogador()
    cutelo.DanoDaArma()
    cutelo.AtributoAdicionalAleatorio()
    cutelo.ClasseDaArma()
    return cutelo

def CuteloLendaria():
    cutelo = Arma("cutelo", 18, 3)
    cutelo.EscolherRaridade("lendaria")
    cutelo.NívelComParametroJogador()
    cutelo.DanoDaArma()
    cutelo.AtributoAdicionalAleatorio()
    cutelo.ClasseDaArma()
    return cutelo

# CUTELO DUPLO

def CuteloDuploComum():
    cutelo = Arma("cutelo duplo", 11, 6)
    cutelo.EscolherRaridade("comum")
    cutelo.NívelComParametroJogador()
    cutelo.DanoDaArma()
    cutelo.AtributoAdicionalAleatorio()
    cutelo.ClasseDaArma()
    return cutelo

def CuteloDuploRara():
    cutelo = Arma("cutelo duplo", 16, 6)
    cutelo.EscolherRaridade("rara")
    cutelo.NívelComParametroJogador()
    cutelo.DanoDaArma()
    cutelo.AtributoAdicionalAleatorio()
    cutelo.ClasseDaArma()
    return cutelo

def CuteloDuploÉpica():
    cutelo = Arma("cutelo duplo", 20, 5)
    cutelo.EscolherRaridade("épica")
    cutelo.NívelComParametroJogador()
    cutelo.DanoDaArma()
    cutelo.AtributoAdicionalAleatorio()
    cutelo.ClasseDaArma()
    return cutelo

def CuteloDuploLendaria():
    cutelo = Arma("cutelo duplo", 25, 5)
    cutelo.EscolherRaridade("lendaria")
    cutelo.NívelComParametroJogador()
    cutelo.DanoDaArma()
    cutelo.AtributoAdicionalAleatorio()
    cutelo.ClasseDaArma()
    return cutelo

# MANOPLA

def ManopolaComum():
    manopla = Arma("manopola", 8, 4)
    manopla.EscolherRaridade("comum")
    manopla.NívelComParametroJogador()
    manopla.DanoDaArma()
    manopla.AtributoAdicionalAleatorio()
    manopla.ClasseDaArma()
    return manopla

def manoplaRara():
    manopla = Arma("manopla", 13, 4)
    manopla.EscolherRaridade("rara")
    manopla.NívelComParametroJogador()
    manopla.DanoDaArma()
    manopla.AtributoAdicionalAleatorio()
    manopla.ClasseDaArma()
    return manopla

def manoplaÉpica():
    manopla = Arma("manopla", 18, 3)
    manopla.EscolherRaridade("épica")
    manopla.NívelComParametroJogador()
    manopla.DanoDaArma()
    manopla.AtributoAdicionalAleatorio()
    manopla.ClasseDaArma()
    return manopla

def manoplaLendaria():
    manopla = Arma("manopla", 23, 3)
    manopla.EscolherRaridade("lendaria")
    manopla.NívelComParametroJogador()
    manopla.DanoDaArma()
    manopla.AtributoAdicionalAleatorio()
    manopla.ClasseDaArma()
    return manopla

# KATANA

def KatanaComum():
    katana = Arma("katana", 9, 4)
    katana.EscolherRaridade("comum")
    katana.NívelComParametroJogador()
    katana.DanoDaArma()
    katana.AtributoAdicionalAleatorio()
    katana.ClasseDaArma()
    return katana

def KatanaRara():
    katana = Arma("katana", 15, 4)
    katana.EscolherRaridade("rara")
    katana.NívelComParametroJogador()
    katana.DanoDaArma()
    katana.AtributoAdicionalAleatorio()
    katana.ClasseDaArma()
    return katana

def KatanaÉpica():
    katana = Arma("katana", 18, 3)
    katana.EscolherRaridade("épica")
    katana.NívelComParametroJogador()
    katana.DanoDaArma()
    katana.AtributoAdicionalAleatorio()
    katana.ClasseDaArma()
    return katana

def KatanaLendaria():
    katana = Arma("katana", 20, 33)
    katana.EscolherRaridade("lendaria")
    katana.NívelComParametroJogador()
    katana.DanoDaArma()
    katana.AtributoAdicionalAleatorio()
    katana.ClasseDaArma()
    return katana

# SABRE

def SabreComum():
    sabre = Arma("sabre", 7, 4)
    sabre.EscolherRaridade("comum")
    sabre.NívelComParametroJogador()
    sabre.DanoDaArma()
    sabre.AtributoAdicionalAleatorio()
    sabre.ClasseDaArma()
    return sabre

def SabreRara():
    sabre = Arma("sabre", 10, 4)
    sabre.EscolherRaridade("rara")
    sabre.NívelComParametroJogador()
    sabre.DanoDaArma()
    sabre.AtributoAdicionalAleatorio()
    sabre.ClasseDaArma()
    return sabre

def SabreÉpica():
    sabre = Arma("sabre",15,3)
    sabre.EscolherRaridade("épica")
    sabre.NívelComParametroJogador()
    sabre.DanoDaArma()
    sabre.AtributoAdicionalAleatorio()
    sabre.ClasseDaArma()
    return sabre

def SabreLendaria():
    sabre = Arma("sabre",20,3)
    sabre.EscolherRaridade("lendaria")
    sabre.NívelComParametroJogador()
    sabre.DanoDaArma()
    sabre.AtributoAdicionalAleatorio()
    sabre.ClasseDaArma()
    return sabre