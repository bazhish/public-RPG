from random import choice, randint, uniform

class Arma:
    def __init__(self, nome, dano, peso):
        self.arma = {}
        self.nome = nome
        self.raridades = ["comum", "rara", "épica", "lendaria"]
        self.raridade = ""
        self.dano = dano
        self.bonus = uniform(1.1, 1.9)
        self.peso = peso
        self.atributos = ["dano", "vida", "velocidade", "defesa"]
        self.atributo = ""
        self.nível = 1

    def nivel_da_arma_com_parametro_do_usuario(self, usuario):
        nível = usuario["nível"]
        self.nível = randint(max(0, nível - 3), min(nível + 3, 100))

    def nivel_com_parametro_manual(self, nível):
        self.nível = nível

    def dano_da_arma(self):
        self.dano = self.dano * self.nível

    def velocidade_que_o_usuario_ira_perder(self, usuario):
        if usuario["arma"] is not None:
            usuario["velocidade"] -= self.peso

    def escolha_de_raridade(self, raridade_escolhida):
        if raridade_escolhida in self.raridades:
            self.raridade = raridade_escolhida
        else:
            print("Raridade inválida.")

    def aplicar_bonus_atributo(self, usuario, atributo):
        valores_base = {"dano": 2, "vida": 10, "velocidade": 3, "defesa": 1}
        multiplicador = 1

        if self.raridade == "rara":
            multiplicador = 1.5
        elif self.raridade == "épica":
            multiplicador = 2.3
        elif self.raridade == "lendaria":
            multiplicador = 2.8

        valor = valores_base[atributo] * multiplicador * self.nível
        usuario[atributo] += valor

    def atributo_adicional_aleatorio(self, usuario):
        self.AtributoEscolhido = choice(self.atributos)
        self.aplicar_bonus_atributo(usuario, self.AtributoEscolhido)

    def atributo_adicional_manual(self, atributo, usuario):
        if atributo in self.atributos:
            self.AtributoEscolhido = atributo
            self.aplicar_bonus_atributo(usuario, atributo)
        else:
            print("Atributo inválido.")

    def classe_da_arma(self):
        self.arma = {
            "Arma": self.nome,
            "Raridade": self.raridade,
            "Nível": self.nível,
            "Dano": self.dano,
            "Bonus de experiência": self.bonus,
            "Peso": self.peso,
            "Atributo adicional": getattr(self, 'AtributoEscolhido', None),
        }

        multiplicador = 1
        if self.raridade == "rara":
            multiplicador = 1.5
        elif self.raridade == "épica":
            multiplicador = 2.3
        elif self.raridade == "lendaria":
            multiplicador = 2.8

        self.arma["Dano"] *= multiplicador
        self.arma["Bonus de experiência"] *= multiplicador

        return self.arma

def criar_arma(tipo, raridade, usuario=None):
    tabela_armas = {
        "Espada": {"comum": (6,3), "rara": (11,3), "épica": (18,2), "lendaria": (23,2)},
        "Espada Curta": {"comum": (6,2), "rara": (8,2), "épica": (12,1), "lendaria": (18,1)},
        "Espada Longa": {"comum": (9,4), "rara": (12,4), "épica": (16,3), "lendaria": (24,3)},
        "Espada Dupla": {"comum": (10,5), "rara": (14,5), "épica": (18,3), "lendaria": (21,3)},
        "Adaga": {"comum": (5,3), "rara": (8,3), "épica": (10,2), "lendaria": (13,2)},
        "Adaga dupla": {"comum": (7,5), "rara": (16,5), "épica": (20,4), "lendaria": (26,4)},
        "zarabatana": {"comum": (4,3), "rara": (6,3), "épica": (8,2), "lendaria": (13,2)},
        "besta": {"comum": (6,5), "rara": (9,5), "épica": (12,4), "lendaria": (16,4)},
        "arco": {"comum": (5,3), "rara": (8,3), "épica": (10,2), "lendaria": (16,2)},
        "lança": {"comum": (6,4), "rara": (8,4), "épica": (11,3), "lendaria": (16,5)},
        "machado": {"comum": (8,4), "rara": (10,4), "épica": (16,4), "lendaria": (20,4)},
        "machado duplo": {"comum": (10,6), "rara": (18,6), "épica": (24,6), "lendaria": (26,5)},
        "cutelo": {"comum": (9,4), "rara": (12,4), "épica": (15,3), "lendaria": (18,3)},
        "cutelo duplo": {"comum": (11,6), "rara": (16,6), "épica": (20,5), "lendaria": (25,5)},
        "manopla": {"comum": (8,4), "rara": (13,4), "épica": (18,3), "lendaria": (23,3)},
        "katana": {"comum": (9,4), "rara": (15,4), "épica": (18,3), "lendaria": (20,33)},
        "sabre": {"comum": (7,4), "rara": (10,4), "épica": (15,3), "lendaria": (20,3)},
    }

    if tipo in tabela_armas and raridade in tabela_armas[tipo]:
        dano, peso = tabela_armas[tipo][raridade]
        arma = Arma(tipo, dano, peso)
        arma.escolha_de_raridade(raridade)

        if usuario:
            arma.nivel_da_arma_com_parametro_do_usuario(usuario)
            arma.atributo_adicional_aleatorio(usuario)

        arma.dano_da_arma()
        return arma.classe_da_arma()
