from armas import EspadaCurtaComum, AdagaComum, LancaComum, ArcoComum, ManopolaComum
from _municoes import _flecha
from _escudo import _escudo

espada_cega = EspadaCurtaComum
adaga_sem_ponta = AdagaComum
lança_com_cabo_quebrado = LancaComum
arco_e_flecha_velhos = ArcoComum, _flecha.FlechaComum
soco_espinhado = ManopolaComum
escudo_de_mao = _escudo.EscudoComum
