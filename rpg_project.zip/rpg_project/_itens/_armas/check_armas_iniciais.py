from _itens._armas.check_armas import Arma
from _municoes.check_flecha import Flecha
from _escudo.check_escudo import Escudo

# FUNC ESPADA
def espada_inicial(jogador):
    espada = Arma("espada de ferro enferrujada", 6, 2)
    espada.nivel_com_parametro_manual(1)
    espada.dano_da_arma()
    espada.velocidade_que_o_usuario_ira_perder(jogador)
    espada.escolha_de_raridade("comum")
    espada.atributo_adicional_aleatorio(jogador)
    espada.aplicar_bonus_atributo(jogador, espada.atributo_adicional_aleatorio(jogador))
    espada.classe_da_arma()
    return espada

# FUNC ADAGA
def adaga_inicial(jogador):
    adaga = Arma("adaga sem ponta", 5, 3)
    adaga.nivel_com_parametro_manual(1)
    adaga.dano_da_arma()
    adaga.velocidade_que_o_usuario_ira_perder(jogador)
    adaga.escolha_de_raridade("comum")
    adaga.atributo_adicional_aleatorio(jogador)
    adaga.aplicar_bonus_atributo(jogador, adaga.atributo_adicional_aleatorio(jogador))
    adaga.classe_da_arma()
    return adaga

# FUNC LANÇA
def lanca_inicial(jogador):
    lanca = Arma("lança com o cabo quebrado", 6, 4)
    lanca.nivel_com_parametro_manual(1)
    lanca.dano_da_arma()
    lanca.velocidade_que_o_usuario_ira_perder(jogador)
    lanca.escolha_de_raridade("comum")
    lanca.atributo_adicional_aleatorio(jogador)
    lanca.aplicar_bonus_atributo(jogador, lanca.atributo_adicional_aleatorio(jogador))
    lanca.classe_da_arma()
    return lanca

# FUNC ARCO
def arco_inicial(jogador):
    arco = Arma("arco antigo", 5, 3)
    arco.nivel_com_parametro_manual(1)
    arco.dano_da_arma()
    arco.velocidade_que_o_usuario_ira_perder(jogador)
    arco.escolha_de_raridade("comum")
    arco.atributo_adicional_aleatorio(jogador)
    arco.aplicar_bonus_atributo(jogador, arco.atributo_adicional_aleatorio(jogador))
    arco.classe_da_arma()
    return arco

# FUNC FLECHAS
def flechas_iniciais():
    flecha = Flecha(5, 1)
    flecha.definir_nivel_manual(1)
    flecha.escolher_raridade("comum")
    flecha.escolher_efeito_aleatorio()
    flecha.calcular_dano()
    return flecha


# FUNC MANOPLA
def manopla_inicial(jogador):
    manopla = Arma("soco espinhado", 8, 4)
    manopla.nivel_com_parametro_manual(1)
    manopla.dano_da_arma()
    manopla.velocidade_que_o_usuario_ira_perder(jogador)
    manopla.escolha_de_raridade("comum")
    manopla.atributo_adicional_aleatorio(jogador)
    manopla.aplicar_bonus_atributo(jogador, manopla.atributo_adicional_aleatorio(jogador))
    manopla.classe_da_arma()
    return manopla


# FUNC ESCUDO
def escudo_inicial():
    escudo = Escudo("escudo de mão", 5, 3)
    escudo.definir_nivel_manual(1)
    escudo.escolher_raridade("comum")
    escudo.calcular_defesa()
    escudo.escolher_atributo_adicional_aleatorio()
    escudo.aplicar_bonus_no_jogador()
    return escudo

# ARMAS:

espada = espada_inicial
adaga = adaga_inicial
lanca = lanca_inicial
arco = arco_inicial
flecha = flechas_iniciais
manopla = manopla_inicial
escudo = escudo_inicial