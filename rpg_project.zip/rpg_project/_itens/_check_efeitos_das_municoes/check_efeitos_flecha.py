class EfeitoFlecha:
    def __init__(self, nome, tipo, alcance, duracao, dano_por_turno = 0):
        self.nome = nome
        self.tipo = tipo
        self.alcance = alcance
        self.duracao = duracao
        self.dano_por_turno = dano_por_turno

    def aplicar_efeito(self, alvo: dict):
        if self.dano_por_turno > 0:
            alvo["vida"] -= self.dano_por_turno
        else:
            pass

class Veneno(EfeitoFlecha):
    def __init__(self):
        super().__init__("Veneno", "Dano ao longo do tempo", 10, 3, dano_por_turno = 5)

class Assoviante(EfeitoFlecha):
    def __init__(self):
        super().__init__("Assoviante", "Atração de inimigos", 15, 0)

class Flamejante(EfeitoFlecha):
    def __init__(self):
        super().__init__("Flamejante", "Dano de fogo", 20, 2, dano_por_turno = 10)

class Explosiva(EfeitoFlecha):
    def __init__(self):
        super().__init__("Explosiva", "Dano em área", 25, 1, dano_por_turno =  30)

class Paralisante(EfeitoFlecha):
    def __init__(self):
        super().__init__("Paralisante", "Imobilização temporária", 12, 4)