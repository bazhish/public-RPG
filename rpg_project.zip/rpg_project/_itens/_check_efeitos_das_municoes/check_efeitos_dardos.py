from abc import ABC, abstractmethod

class EfeitoDardo:
    def __init__(self, nome, tipo, alcance, duracao, dano = 0):
        self.nome = nome
        self.tipo = tipo
        self.alcance = alcance
        self.duracao = duracao
        self.dano = dano 

    @abstractmethod
    def aplicar_efeito(ABC):
        pass

class Veneno(EfeitoDardo):
    def __init__(self):
        super().__init__("Veneno", "Dano ao longo do tempo", 5, 3)
        self.dano_por_turno = 3

    def aplicar_efeito(self, alvo: dict):
        for turno in range(self.duracao):
            alvo["vida"]-= self.dano_por_turno

class Flamejante(EfeitoDardo):
    def __init__(self):
        super().__init__("Flamejante", "Dano de fogo", 20, 2)
        self.dano_por_turno = 6

    def aplicar_efeito(self, alvo: dict):
        for turno in range(self.duracao):
            alvo["vida"] -= self.dano_por_turno

class Paralisante(EfeitoDardo):
    def __init__(self):
        super().__init__("Paralisante", "Imobilização temporária", 6, 4)

    def aplicar_efeito(self, alvo: dict):
        alvo["velocidade"] = 0  

class Tranquilizante(EfeitoDardo):
    def __init__(self):
        super().__init__("Tranquilizante", "Redução de velocidade", 5, 5)

    def aplicar_efeito(self, alvo: dict):
        alvo["velocidade"] = max(0, alvo["velocidade"] - 2)


class Assoviante(EfeitoDardo):
    def __init__(self):
        super().__init__("Assoviante", "Atração de inimigos", 15, 0)

class Explosiva(EfeitoDardo):
    def __init__(self):
        super().__init__("Explosiva", "Dano em área", 12, 1, dano = 12)

    def aplicar_efeito(self, alvo: dict):
        alvo["vida"] -= self.dano

