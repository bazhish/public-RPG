import random
from _jogador._jogador.check_jogador_ficticio import jogador

class Escudo:
    raridades = ["comum", "rara", "épica", "lendaria"]
    fatores_raridade = {
        "comum": 1.0,
        "rara": 1.5,
        "épica": 2.3,
        "lendaria": 2.8
    }

    def __init__(self, nome, defesa_base, peso):
        self.nome = nome
        self.defesa_base = defesa_base
        self.peso = peso
        self.nivel = 1
        self.raridade = "comum"
        self.atributo_adicional = None
        self.defesa_final = defesa_base

    def definir_nivel_com_base_no_jogador(self):
        nivel_jogador = jogador["nível"]
        self.nivel = random.randint(max(1, nivel_jogador - 3), min(nivel_jogador + 3, 100))

    def definir_nivel_manual(self, nivel):
        if 1 <= nivel <= 100:
            self.nivel = nivel
        else:
            print("Nível inválido. Deve ser entre 1 e 100.")

    def escolher_raridade(self, raridade):
        if raridade in self.raridades:
            self.raridade = raridade
        else:
            print("Raridade inválida. Mantendo 'comum'.")

    def calcular_defesa(self):
        fator = self.fatores_raridade.get(self.raridade, 1.0)
        self.defesa_final = self.defesa_base * self.nivel * fator

    def escolher_atributo_adicional_aleatorio(self):
        atributos = ["defesa", "vida", "velocidade"]
        self.atributo_adicional = random.choice(atributos)

    def aplicar_bonus_no_jogador(self):
        """
        Aplica o atributo adicional diretamente no jogador fictício.
        """
        defesa_bonus = 2
        vida_bonus = 10
        velocidade_bonus = 3

        fator = self.fatores_raridade.get(self.raridade, 1.0)
        defesa_bonus *= self.nivel * fator
        vida_bonus *= self.nivel * fator
        velocidade_bonus *= self.nivel * fator

        if self.atributo_adicional == "defesa":
            jogador["defesa"] += defesa_bonus
        elif self.atributo_adicional == "vida":
            jogador["vida"] += vida_bonus
        elif self.atributo_adicional == "velocidade":
            jogador["velocidade"] += velocidade_bonus

    def gerar_dict(self):
        self.calcular_defesa()
        return {
            "Nome": self.nome,
            "Nível": self.nivel,
            "Raridade": self.raridade,
            "Defesa": self.defesa_final,
            "Peso": self.peso,
            "Atributo adicional": self.atributo_adicional,
        }

    def __repr__(self):
        return (f"<Escudo '{self.nome}' nivel={self.nivel} raridade='{self.raridade}' "
                f"defesa={self.defesa_final:.1f} atributo='{self.atributo_adicional}'>")

def escudo_comum():
    e = Escudo("Escudo", 5, 3)
    e.escolher_raridade("comum")
    e.definir_nivel_com_base_no_jogador()
    e.escolher_atributo_adicional_aleatorio()
    e.aplicar_bonus_no_jogador()
    return e

def escudo_rara():
    e = Escudo("Escudo", 7, 3)
    e.escolher_raridade("rara")
    e.definir_nivel_com_base_no_jogador()
    e.escolher_atributo_adicional_aleatorio()
    e.aplicar_bonus_no_jogador()
    return e

def escudo_epica():
    e = Escudo("Escudo", 10, 2)
    e.escolher_raridade("épica")
    e.definir_nivel_com_base_no_jogador()
    e.escolher_atributo_adicional_aleatorio()
    e.aplicar_bonus_no_jogador()
    return e

def escudo_lendaria():
    e = Escudo("Escudo", 15, 2)
    e.escolher_raridade("lendaria")
    e.definir_nivel_com_base_no_jogador()
    e.escolher_atributo_adicional_aleatorio()
    e.aplicar_bonus_no_jogador()
    return e
