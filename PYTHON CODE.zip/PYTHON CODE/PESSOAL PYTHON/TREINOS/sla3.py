class Aluno():
    def __init__(self, nome, nota1, nota2, nota3):
        self.aluno = nome
        self.nota1 = nota1
        self.nota2 = nota2
        self.nota3 = nota3

    def CaucularMédia(self):
        Média = (self.nota1 + self.nota2 + self.nota3) // 3
        print(f"a média do {self.aluno} foi: {Média}")

aluno = Aluno("joão", 7, 1, 3)
aluno.CaucularMédia()