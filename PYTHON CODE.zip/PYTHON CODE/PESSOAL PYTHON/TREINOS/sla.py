class Livro():
    def __init__(self, titulo, autor, paginas):
        self.titulo = titulo
        self.autor = autor
        self.paginas = paginas

    def Exibir(self):
        return f"o livro é {self.titulo}, escrito por {self.autor}, e tem {self.paginas} paginas"

teste = Livro("A branca de neve", "Jakob Ludwig Karl Grimm", 80)

print(teste.Exibir())