import sys

class ContaBancaria():
    def __init__(self, nome):
        self.nome = nome
        self.saldo = 0

    def Depositar(self):
        self.deposito = int(input("Digite o valor do deposito: "))
        self.saldo += self.deposito
        print(f" seu saldo é {self.saldo}")
        
    def Saldo(self):
        self.saldo
        print(f" seu saldo é {self.saldo}")

    def Sacar(self):
        self.sacar = int(input("digite o valor que vc deseja sacar: "))
        if self.sacar > self.saldo:
            print("Saldo insuficiente!")
        self.saldo -= self.sacar
        print(f" seu saldo é {self.saldo}")


Usuario = ContaBancaria("João")
while True:
    botão = input("aperte '1' para depositar\naperte '2' para ver saldo\naperte '3' para sacar\n aperte '4' para sair>")
    if botão == "1":
        Usuario.Depositar()
        
    elif botão == "2":
        Usuario.Saldo()
               
    elif botão == "3":
        Usuario.Sacar()

    elif botão == "4":
        print("bye bye")
        sys.exit(0)














