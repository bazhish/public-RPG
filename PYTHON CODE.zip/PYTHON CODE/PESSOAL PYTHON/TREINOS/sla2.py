import sys

class Carro():
    def __init__(self, marca, modelo, ano):
        self.marca = marca
        self.modelo = modelo
        self.ano = ano

    def LigarDesligar(self):
        while True:
            botão = input("aperte 'G' para ligar\naperte 'H' para desligar\naperte 'F' para sair\n\n>").upper()
            if botão == "G":
                print(f"o {self.modelo} está ligado")
                
            elif botão == "H":
                print(f"o {self.modelo} está desligado")
               

            elif botão == "F":
                print("bye bye")
                sys.exit(0)
                


MClarem = Carro("MClarem", "720s", 2017)

print(MClarem.LigarDesligar())
