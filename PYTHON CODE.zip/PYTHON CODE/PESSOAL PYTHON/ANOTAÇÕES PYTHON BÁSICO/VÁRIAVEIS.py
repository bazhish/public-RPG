# Váriaveis

"""váriavel é uma espaço na memoria onde você guarda um valor definido com um nome que você escolheu, 
voce pode usar este nome posteriormente para se rferir a este valor, sendo alngus tipos:"""

nome = ("islan") # Str(texto)
print(f"meu nome é {nome}")

número = (10) # Int(número inteiro)
print(f"100 dividido por 10 é {número}")

quebrado = (0.3) # Float(número com virgula)
print(f"3 dividido por 10 é {quebrado}")

verdadeiro_falso = (True) # Bool(lógico)
print(f"verdadeiro em inglês é {verdadeiro_falso}")

lista = [1, 2, 3, 4,] # Lista de algo
print(f"aqui está uma sequência do 1 ao 4: {lista}")

dicionario = {
    "nome": "anderson",
    "cargo": "professor",  # Nome e descrição
    "aula": "técnico"
}
print(f"perfil = {dicionario}")

range(0,10) # Faixa de valores em sequência de 0 a 10
print(f"aqui está uma sequeência do 0 ao 10 {range}")

sequência = set(1,2,2,2,2,2,3) # Faixa de valores sem ordem (exibe apenas 1 dos valores se tiver mais de 2 valores iguais)
print(f"aqui está uma sequência do 1 ao 3{sequência}")

lista_inalteravel = tuple(1,2,3,4,5) #lista que não pode ser alterada
print(lista_inalteravel[3])

sem_valor = None #ausência de valor
print(f"zero é um numero sem valor, então em python seria {sem_valor}")

"""regras com os nomes das veriaveis:"""

# Pode usar letras, números e underlines
# Não pode começar com número
# Não pode ter espaço
# Não pode usar palavras reservadas(ex:print, if, del)

#você pode mudar o valor a qualque momento

valor = 10
valor + 1 #agora "x" vale 11
print(f"{valor}")

# Atribuição multipla significa poder definir varias variaveis em uma linha

a, b, c = 1, 2, 3
print(f"{a}", end = " ")
print(f"{b}", end = " ")
print(f"{c}", end = ".")

# Ou dar o mesmo valor para varias

x = y = z = 10

print(x)
print(y)
print(z)

# Variaveis locais e globais

islan = ("homem") # Variavel global
print(islan)

def teste():
    islan = ("menino")  # Variavel local:
    print(islan)

# Mas se quiser usar a global dentro da funçãoo faça o seguinte

def teste():
    global laura
    laura = ("mulher")