# Exibição

"""Print: Print é uma função usada para exibir informações no terminal, tudo o que você coloca dentro dos 
parênteses será mostrado na tela.""" 

print("hello, world!")

"""Você pode imprimir vários valores separados por vírgulas, e o Python vai 
colocar um espaço entre eles automaticamente. A função tem alguns parâmetros opcionais que mudam seus 
comportamentos, sendo eles:"""

# Sep: (separador)
"""sep: Define o que será colocado entre um código e outro."""

print("hello", "world", sep = "_")

# End: (o que será colocado no final)
"""end: Por padrão, a função termina em uma quebra de linha, mas você pode mudar isso usando o parâmetro end."""

print("hello", "world", end = ",")
print("i am islan", end = ".")

# File: (onde imprimir) File e flush não são tão importantes mas é bom saber.
"""file: Por padrão, o print mostra coisas na tela, mas se quiser, pode mandar o texto para um arquivo.
O texto não aparecerá no terminal, mas sim no arquivo."""

with open("log.txt", "w") as f:  # Usamos "with open" para abrir e fechar um arquivo e "as" para nomeá-lo

    print("mensagem que será salva no arquivo", file=f) # Usamos file para salvar

# Flush: (forçar a atualização) File e flush não são tão importantes mas é bom saber.
"""flush: Flush força o conteúdo a aparecer imediatamente na tela, independente de qual linha esteja."""

print("carregando...", flush=True) 

# Existem vários tipos de print, como:

# String (str):
"""String (str) é qualquer texto que esteja entre aspas duplas ou simples dentro dos parênteses, 
pode conter letras, números, símbolos, espaços e tudo isso junto. Mas se não estiver entre aspas, 
não é uma string."""

print("isso é uma string") # Apenas letras

#números (num):
"""numeros (num) é qualquer número que você digitar dentro dos parênteses fora das aspas """
print(1278935) # Apenas números

# Listas (list):
"""Lista (list): É como criar uma caixa que guarda vários valores, um atrás do outro, pode existir números,
textos, símbolos."""

números = [1, 2, 3] # Números
nomes = ["islan", "victor", "guilherme"] # Textos
mistura = ["nome", 1, False] # Misturados

print(números[2])  # Será exibido o número 3
print(nomes[1])    # Será exibido "victor"

números[0] = 6          # Altera valores
números.append(4)       # (append) Adiciona valores
números.remove(2)       # (remove) Remove valores

# Dicionários (dict):
"""Dicionário (dict): É uma coleção de pares: chave → valor, tipo uma ficha de nome de cada coisa
e o valor ligado a ela."""

pessoa = {
    "nome": "islan",
    "idade": "16",
    "estado": "sp"
}

print(pessoa["nome"])   # Islan
print(pessoa["idade"])  # 16
print(pessoa["estado"]) # Sp

del pessoa["estado"]  # Remove algo do dicionário

#Com números podemos realizar operações usando símbolos próprios da matemática.

# Operadores aritméticos:

print(1 + 1)   # + Soma
print(2 - 1)   # - Subtração
print(2 * 2)   # * Multiplicação
print(4 / 2)   # / Divisão
print(7 // 2)  # // Divisão inteira
print(7 % 2)   # % Resto da divisão
print(2 ** 2)  # ** Potência

# Operadores de comparação (True/False):

print(5 == 5)   # == Igualdade
print(5 != 1)   # != Diferença
print(5 > 2)    # > Maior que
print(2 < 5)    # < Menor que
print(5 >= 5)   # >= Maior ou igual
print(8 <= 4)   # <= Menor ou igual

# Operadores lógicos:

print(3 + 2 and 2 * 4)   # and (ambos verdade)
print(2 + 2 or 2 * 2)    # or (um ou outro)

print(not 6 + 3 == 3 * 3)  # not (inverte)

# Operadores de atribuição:

x = 10 # = Atribui um valor
x += 1 # += Soma um valor ao valor já atribuido
x -= 2 # -= Subtrai um valor ao valor já atribuido
x *= 3 # *= Multiplica um valor ao já atribuido
x /= 4 # / Divide o valor já valor já atribuido
x //= 5 # // Divisão interia do valor já atribuido
x %= 6 # % Resto da divisão ao valor atribuido
x **= 7 # Potênciação do valor atribuido

# Operadores de identidade e pertencimento:

print("a" in "max")            # In (para checar se "a" está dentro de "max")
print(3 not in [1, 2, 4, 5])   # Not in (para checar "3" não está dentro da lista)

#Temos também caracteres especiais que servem para formatar o texto

print("\nhello\nworld!")   # \n (vai para póxima linha)
print("\thello\tworld")    # \t (cria um espaço)
print("\\hello\\world")    # \\ (adiciona um barra invertida)
print("\'hello\'world")    # \' (adiciona aspas simples)
print("\rhello\rworld")    # \r (Retorna uma palavra)
print("\bhello\bworld")    # \b (Apaga a letra anterior (pode não ser visível em todos os consoles))
print("\ahello\aworld")    # \a (emite som)

# Formatação moderna (f"strings")

eu = "max" # Váriaveis
irmão = "victor" # Váriaveis
namorada = "Laura" # Váriaveis

print(f"meu nome é {eu}, e esse é meu irmão {irmão}, e essa é minha namorada {namorada}. prazer em conhecer a todos")

#Print com repetições e multiplicações significa que você pode multiplicar uma str

print("-" * 10)  # Multiplicação direta

#Print com uma linha com vários parametros.

print("data:", 12, 4, 2025, sep="/") # STR and NUM