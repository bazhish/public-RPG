# Condições

# sourcery skip: remove-redundant-if
"""Condições em python é a base para qualquer decisão no código, e com elas escolher diferentes caminhos"""

#if(se) Executa uma determinada coisa se uma ação for verdadeira.

idade = 18
if idade >= 18:
    print("você é maior de idade")

#else(senão) É executado caso if seja falso.

else:
    print("você é menor de idade")

#lif(se não se) Serve para testas oustras opções entre o if e o else.

nota = 7

if nota > 7:
    print("você está de parabens")

elif nota == 7:
    print("você passou!")

else:
    print("você não passou")

# Condição com operadores: são aquelas que você pode usar comparações e operadores lógicos.

nome = "islan"
senha = 1234

if senha == 1234 and nome == "islan":
    print("entrada permitida")

# Condição aninhada: é quando usamos um if dentro do outro.

idade = 12
habilitação = False

if idade >= 18:
    if habilitação:
        print("pode dirigir")
    else:
        print("precisa ter carteira")
else:
    print("precisa ser maior")

# Operador ternario:é uma forma compacta do if/else onde você decide os dois valores em uma linha.

idade = 17 # Menor
status = "maior" if idade >= 18 else "menor"
print(status)  

# Pass: se ultiliza quando você controi umas estrutura e deixa pra programar depois.

if True:
    pass # Não faz nada 
elif True:
    pass  # Não faz nada
else:
    pass  # Não faz nada

# Existe tambem math e case: que é uma estrutura parecida com switch.

dia = "segunda"

match dia:
    case "segunda": 
        print("primeiro ddia útil")
    case "sexta":
        print("Último dia útil")
    case "quarta":
        print("meio da semana")
    case "sábado":
        print("final de semana")
    case "domindo":
        print("final de semana")
    case _:
        print("outro dia da semana")

# Encadeamento inteligente com "in": invés de ultilizarmos varios "or" simplificamos com "in"

letra = str(input("digite uma letra"))

if letra in {"a", "e", "i", "o", "u"}:
    print("É vogal")
else:
    print("não é vogal")

# Comparações encadeadas: são simplificadores de operadores.

a = 10
b = 5
c = 2

if a > b > c:
    print("Ordem correta")
else:
    print("ordem incorreta")