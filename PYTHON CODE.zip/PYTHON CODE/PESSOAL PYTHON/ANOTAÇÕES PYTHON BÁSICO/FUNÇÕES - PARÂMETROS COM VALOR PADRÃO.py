# Parâmetros com valor padrão

""" Você pode definir um valor padrão para um parâmetro, isso faz com que o usuário não seja obrigado a definir um argumento para aqula função"""

def saudacao(usuário = "visitante"):
    print(f"Salve, {usuário}!")

saudacao("Islan")  # Salve, Islan!
saudacao() # Salve, visitante!

# Se o nome for informado, usa ele.
# Se nada for informado, usa "visitante".

# Você pode ter vários parâmetros opcionais:

def somar(a=0, b=0):
    return a + b

print(somar(5, 10))  # 15
print(somar(7))      # 7 (b = 0)
print(somar())       # 0 (a = 0, b = 0)

# Regras: Os parâmetros com valor padrão devem ficar depois dos obrigatórios.

"""
def exemplo(a, b=2):  # Certo
    return a + b

def errado(a=2, b):   # Errado
    return a + b
"""