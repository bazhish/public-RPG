# Função

"""função é um bloco de código que você define uma vez e pode usar várias vezes.
Ajuda a organizar e reaproveitar seu código."""

# Como criar uma função?

def nome_da_funcao(): # Define (def) é o código que define a função, logo em seguida damos um nome a ela
    pass # Como não definimos algo para a função ultilizamos pass para não dar erro

# Exemplo real

def saudacao():
    print("Hello World!") # É o que a função vai fazer

saudacao() # Chamamos a função, no caso, ela executa o print

""" Parêmentros: Quando você cria uma função, você pode dizer pra ela esperar valores,
esses valores são os parâmetros."""

def meu_nome(nome): # Nome é o paramentro, o valor que a função espera receber
    print(f"meu nome é {nome}") # Exibimos igual exibimos uma variavel

meu_nome("islan") # Assim definimos o valor do parametro, islan é o argumento

# Uma função pode ter mais que um parâmentro

def somar(a, b): # a, b são os parâmentros
    resultado = a + b # criamos uma váriavel para somar os valores
    print(f"A soma é: {resultado}")
somar(1, 1) # A virgula separa os valores que serão somados

# Funções que retornam valores (return): return guarda o valor para que consiga ser usado depois.
# Pode ser armazenado em uma variável, usado em print:

def multiplicar(x, y):
    return x * y # Retorna o valor a quem chamou a função, no caso o print

resultado1 = multiplicar(3, 4)
print(f"Resultado: {resultado1}")

# Função com valor padrão é quando definimos um valor fixo ao paramentro para caso não for definido posteriormente

def usuario(usuario = "visitante"):
    print(f"Bem vindo: {usuario}!")

usuario() # Será exibido: Bem vindo visitante!
usuario("Islan") #Será exibido: Bem vindo Islan!

# Função com entrada de dados é quando usamos input para definir o valor do parâmentro:

def nome_do_usuario():
    usuario_nome = input("Digite seu nome: ")
    print(f"Seja bem vindo {usuario_nome}")
nome_do_usuario()

# Função que retorna mais de um valor 

def dividir(n):
    return n // 2, n % 2
parte_inteira, resto = dividir(9)
print(parte_inteira, resto)  # Parte inteira = 9, resto = 1

# Função aninhada segue o mesmo conceito os outros aninhamento

def externa():
    def interna():
        print("Sou interna")

    print("Sou externa")
    interna()