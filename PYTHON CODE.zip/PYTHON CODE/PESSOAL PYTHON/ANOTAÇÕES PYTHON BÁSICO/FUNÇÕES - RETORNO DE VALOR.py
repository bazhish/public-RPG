# Return

# O return faz a função mostrar um valor pra quem chamou ela.

def somar(a, b):
    return a + b

resultado = somar(5, 3) # Não vai mostar aqui
print(resultado)  # Vai mostrar aqui

# Aqui a função somar devolve o valor a + b, e esse valor é guardado na variável resultado.

"""
O que acontece por trás:

somar(5, 3)  # vira 8
resultado = 8
print(resultado)  # mostra 8
"""
# Diferença de return e print:

def com_print():
    print("Sou um print")

def com_return():
    return "Sou um return"

x = com_print()    # Isso só mostra na tela, mas x = None
y = com_return()   # Isso guarda "Sou um return" dentro de y

print("x =", x)
print("y =", y)
