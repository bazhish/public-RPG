# Repetições

"""repetições ou tambem muito conhecidas como loops ou laços são usados para repitir blocos de códigos 
varias vezes, até umas condição for atendida ou uma lista acabar"""

# While(enquanto): repete até a condição ser verdadeira(pode ser parado com break)

senha = ""

while senha != "1234":
    senha == int(input("Digite a senha: "))

print("Acesso liberado!")

# Pode ser parado com "break"

while True:
    comando = input("Digite 'sair' para parar: ")
    if comando == "sair":
        break # Break = parar o loop


# For(para cada): usado para percorrer algo como list, str, int.

nomes = ["Islan", "Max", "Costa"]

for nome in nomes:
    print("Olá", nome)

for número in range(5):
    if número == 3:
        continue  # Continue = pular para o próximo (pula o 3)
    print(número)

# Else no loop: O else roda quando o loop termina naturalmente (sem break)

for número in range(10):
    print(número)
else:
    print("Fim do for")

# Aninhamento de loop:

for numero in range(10): # Externo
    for numiro in range(20): # Interno
        print(f"{numero} - {numiro}")

# Unir duas listas: serve pra percorrer duas listas ao mesmo tempo "zip()".

irmãos = ["Islan", "Victor", "Guilherme"]
idades = [18, 20, 25]

for nome, idade in zip(nomes, idades):
    print(f"{irmãos} tem {idade} anos")

# While com menu: útil pra simular sistemas:

while True:
    print("1 - Ver perfil")
    print("2 - Sair")

    opcao = input("Escolha: ")

    if opcao == "1":
        print("Perfil de Islan")
    elif opcao == "2":
        print("Saindo...")
        break
    else:
        print("Opção inválida")