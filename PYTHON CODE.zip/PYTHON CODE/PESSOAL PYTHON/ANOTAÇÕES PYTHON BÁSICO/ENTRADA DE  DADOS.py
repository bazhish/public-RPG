# Entrada de dados: 

"""entrada de dados é como o úsuario digita algo e o programa usa essa informação."""

# Input: usamos o input para que o usuario consiga digitar algo.

nome = input("Digite seu nome: ")
print(f"Olá,{nome}")

# Tudo o que for idgitado vai ser armazenado na váriavel "nome"

# Convertendo os dados para número:
# Todo input retorna como uma string, mas podemos alterar sua clasee inserindo-a antes do input:

número_inteiro = int(input("Digite sua idade: ")) #(int) números inteiros.
print(f"Daqui a 10 anos você terá", {número_inteiro} + 10)  

numero_decimal = float(input("quanto é 7 dividido por 2?")) #(float) Números quebrados.
print(f"{numero_decimal}")

texto = str(input("digite: ")) #(str) Tudo será convertido para texto.

# Entrada multipla:
"""Entrada múltipla: você pode pedir várias coisas de uma vez com a função split, o split é um método
das strings que quebra um texto em partes menores trnsformando em lista, por padrão ele quebra nos
espaços em branco,e o resultado é uma lista com cada pedaço do texto, você pode definir o separador iguaal
definimos sep = "" """

nome, idade = input("Digite nome e idade: ").split(",")

idade = int(idade) # Para garantir que idade será um número inteiro

print("Nome:", nome)
print("Idade:", idade)

# Entrada com lista: Se o usuário digitar vários números separados por espaço criará uma lista:

numeros = input("Digite vários números: ").split()
print(numeros)  # Vira lista de strings

"""Se quiser converter todos para lista numerica ultilizamos o map, map é uma ferramenta
que aplica uma função a cada item da lista, tipo: pega cada item e faz isso com ele"""

numeros = list(map(int(input("Digite varios números: ").split(","))))
print(numeros)

# Input sem mensagem: você tambem pode usar o input sem uma mensagem refrentem mas é sempre bom colocar uma mensagem

input_sem_mensagem = input("")
print(f"{input_sem_mensagem}")

"""Quebra de linha no input: Se quiser que o usuário digite vários dados separados por linha,
pode usar vários input seguidos ou usar \ n """

quebra_de_linha1 = input("1:")
quebra_de_linha2 = input("2:")
quebra_de_linha3 = input("3:")

print(f"{quebra_de_linha1, quebra_de_linha2, quebra_de_linha3}")

# Ou

quebra_de_linha4 = input("1: \n2: \n3: ")

print(f"{quebra_de_linha4}")