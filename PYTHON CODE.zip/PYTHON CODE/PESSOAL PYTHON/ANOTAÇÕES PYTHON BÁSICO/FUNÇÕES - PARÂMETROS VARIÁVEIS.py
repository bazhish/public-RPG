# *args - vários argumentos posicionais
# *args permite passar vários valores como se fossem uma lista de uma função

def somar_tudo(*numeros):
    total = 0
    for n in numeros:
        total += n
    return total

print(somar_tudo(1, 2, 3))      # 6
print(somar_tudo(10, 20, 30))   # 60
print(somar_tudo())             # 0

# *numeros vira uma tupla com todos os valores passados.

# **kwargs — Vários argumentos nomeados (em forma de dicionário)
# **kwargs permite passar vários pares de chave=valor, como se fosse um dicionário.

def mostrar_dados(**info):
    for chave, valor in info.items():
        print(f"{chave}: {valor}")

mostrar_dados(nome="Islan", idade=17, cidade="Salvador")

# **info vira um dicionário com os dados.

# Combinação de tudo: Você pode usar tudo junto:

def exemplo(a, b=0, *args, **kwargs):
    print("a:", a)
    print("b:", b)
    print("args:", args)
    print("kwargs:", kwargs)

exemplo(1, 2, 3, 4, 5, nome="Islan", idade=17)