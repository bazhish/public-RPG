import time, sys

# LOOP PRINCIPAL
while True:
    # MENU INICIAL
    print("\nCAUCULADORA DE TEMPERATURA\n") # MENSAGEM PADRÃO
    
    time.sleep(1.25) # PEQUENA PAUSA
    
    # ESCOLHA DE  TRANSFORMAÇÃO DE TEMPERATURA
    
    escolha_de_temperatura = str(input(
        "Escolha:\n\n"
        "1 - Transformar Celsius para Fahrenheit.\n"
        "2 - Transformar Fahrenheit para Celsius.\n"
        "3 - Transformar Celsius para kelvin.\n"
        "4 - Transformar Kelvin para Celsius.\n"
        "5 - Transformar Fahrenheit para Kelvin.\n"
        "6 - Transformar Kelvin para Fahrenheit.\n"
        "7 - Sair.\n\n"
        "Digite sua resposta: "))
    time.sleep(0.75)
    
    # SOLUÇÃO CASO O USUARIO DIGITE UMA RESPOSTA NÃO REGISTRADA
    repostas_possiveis_menu_principal = ("1", "2", "3", "4", "5", "6", "7")
    if escolha_de_temperatura not in repostas_possiveis_menu_principal:
        print("\nResposta não encontrada.\nPor favor digite um número de 1 a 7!\n")
        time.sleep(1)
        continue
    
    # LOOP SECUNDARIO PARA RETIÇÃO DE CONVERSÃO
    while True:
        # VERIFICA SE HÁ ERRO NO CODIGO
        try:
            if escolha_de_temperatura == "1":
                celsius = float(input("\nDigite a temperatura em Celsius: "))
                fahrenheit = celsius * 9/5 + 32
                print(f"\t\nSua temperatura em Fahrenheit é {fahrenheit:.2f}°F")
            
            elif escolha_de_temperatura == "2":
                fahrenheit = float(input("\nDigite sua temperatura em Farenheit: "))
                celsius = (fahrenheit - 32) * 5/9
                print(f"\t\nSua temperatura em Celsius é {celsius:.2f}")
            
            elif escolha_de_temperatura == "3":
                celcius = float(input("\nDigite a temperatura em Celsius: "))
                kelvin = celcius + 273.15
                print(f"\t\nSua temperatura em Kelvin é {kelvin:.2f} K")
            
            elif escolha_de_temperatura == "4":
                kelvin = float(input("\nDigite a temperatura em Kelvin: "))
                celcius = kelvin - 273.15
                print(f"\t\nSua temperatura em Celsius é {celcius:.2f}°C")
            
            elif escolha_de_temperatura == "5":
                fahrenheit = float(input("\nDigite a temperatura em Fahrenheit: "))
                kelvin = (fahrenheit - 32) * 5/9 + 273.15
                print(f"\t\nSua temperatura em Kelvin é {kelvin:.2f} K")
            
            elif escolha_de_temperatura == "6":
                kelvin = float(input("\nDigite a temperatura em Kelvin: n"))
                fahrenheit = (kelvin - 273.15) * 9/5 + 32
                print(f"\t\nSua temperatura em Fahrenheit é {fahrenheit:.2f}°F")
            
            elif escolha_de_temperatura == "7":
                time.sleep(0.75) 
                print("\nGoodBye!\n")
                sys.exit(0) # ENCERRA TUDO
            
        # CORREÇÃO DE ERRO CASO O USURIARIO DIGITE ALGO DIFERENTE DE NÚMEROS
        except ValueError:
            print("\nPor favor, Digite penas números!")
            time.sleep(0.8)
            continue
        
        time.sleep(1.25) # PEQUENO PAUSE PÓS CAUCULO
        
        # LOOP TERCIARIO PARA DECISÃO DO USUARIO
        laço_terciario_quebrado = 0 # GAMBIARRA PARA ENCERRAR O LOOP DO MENU SECUNDARIO E REPETIR A MESMA FORMULA DE CONVERSÃO
        while True:
            # MENU SECUNDARIO
            escolha_de_decisão = str(input(
                "\nDeseja realizar mais algum cálculo?\n\n"
                "1 - Não, sair.\n"
                "2 - Sim, nova operação.\n"
                "3 - Realizar mesmo cáuculo de conversão.\n\n"
                "Digite sua resposta: "))
            
            # SOLUÇÃO CASO O USUARIO DIGITE UMA RESPOSTA NÃO REGISTRADA
            repostas_possiveis_menu_secundario = ("1", "2", "3")
            if escolha_de_decisão not in repostas_possiveis_menu_secundario:
                print("\nResposta não encontrada.\nPor favor digite um número de 1 a 3!\n")
                continue
            
            if escolha_de_decisão == "1":
                time.sleep(0.75) 
                print("\nGoodBye!\n")
                sys.exit(0) # ENCERRA TUDO
            
            elif escolha_de_decisão == "2":
                laço_terciario_quebrado += 1 # GAMBIARRA PARA ENCERRAR O LOOP DO MENU SECUNDARIO E REPETIR A MESMA FORMULA DE CONVERSÃO
                break # ENCERRA O LOOP TERCIARIO
            
            elif escolha_de_decisão == "3":
                break # RETEPE A MESMA FORMULA
        
        if laço_terciario_quebrado > 0: # GAMBIARRA PARA ENCERRAR O LOOP DO MENU SECUNDARIO E REPETIR A MESMA FORMULA DE CONVERSÃO
            break # ENCERRA O LOOP SECUNDARIO