import openai
import requests

# Chaves da API
OPENAI_API_KEY = "SUA_CHAVE_OPENAI"
SERP_API_KEY = "SUA_CHAVE_SERPAPI"

# Inicializa cliente OpenAI
client = openai.OpenAI(api_key=OPENAI_API_KEY)

# Função de busca na internet via SerpAPI
def buscar_na_web(pergunta):
    url = "https://serpapi.com/search"
    params = {
        "hl": "pt-br",
        "gl": "br",
        "api_key": SERP_API_KEY
    }
    resposta = requests.get(url, params=params)
    dados = resposta.json()

    if "organic_results" in dados:
        return dados["organic_results"][0].get("snippet", "Nenhuma informação detalhada.")
    return "Não encontrei nada na web."

# Função de resposta usando GPT + web
def gerar_resposta(pergunta):
    info_web = buscar_na_web(pergunta)

    prompt = f"Pergunta: {pergunta}\nInformação da web: {info_web}\nResponda de forma direta e clara:"

    resposta = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )

    return resposta.choices[0].message.content

# Loop do chatbot
if __name__ == "__main__":
    print("🤖 ChatBot com GPT + Web Search (digite 'sair' para encerrar)\n")
    while True:
        pergunta = input("Você: ")
        if pergunta.lower() in ["sair", "exit", "quit"]:
            print("Bot: Até a próxima!")
            break
        try:
            resposta = gerar_resposta(pergunta)
            print("Bot:", resposta)
        except Exception as e:
            print("❌ Erro:", e)
