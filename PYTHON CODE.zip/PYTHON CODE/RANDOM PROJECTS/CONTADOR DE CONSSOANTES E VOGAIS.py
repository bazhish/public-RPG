palavra = input("Digite a palavra:\n").lower()
vogais = ("a", "á", "ã", "à", "â", "e", "ê", "é", "è", "i", "î", "í", "ì", "o", "õ", "ô", "ó", "ò", "u", "û", "ú", "ù")
consoantes = ("b", "c", "ç", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z")

contador_vogais = 0
contador_consoantes = 0

for letra in palavra:
    if letra in vogais:
        contador_vogais += 1

for letra in palavra:
    if letra in consoantes:
        contador_consoantes += 1

print(f"Total de vogais: {contador_vogais}")
print(f"Total de consoantes: {contador_consoantes}")
