elementos = {
    'h': {'nome': 'Hidrogênio', 'numero_atomico': 1, 'massa': 1.008},
    'he': {'nome': 'Hélio', 'numero_atomico': 2, 'massa': 4.0026},
    'li': {'nome': 'Lítio', 'numero_atomico': 3, 'massa': 6.94},
    'be': {'nome': 'Berílio', 'numero_atomico': 4, 'massa': 9.0122},
    'b': {'nome': 'Boro', 'numero_atomico': 5, 'massa': 10.81},
    'c': {'nome': 'Carbono', 'numero_atomico': 6, 'massa': 12.011},
    'n': {'nome': 'Nitrogênio', 'numero_atomico': 7, 'massa': 14.007},
    'o': {'nome': 'Oxigênio', 'numero_atomico': 8, 'massa': 15.999},
    'f': {'nome': 'Flúor', 'numero_atomico': 9, 'massa': 18.998},
    'ne': {'nome': 'Neônio', 'numero_atomico': 10, 'massa': 20.180},
}
while True:
    sigla = input("Digite a sigla de um elemento químico: ").lower()

    if sigla in elementos:
        elemento = elementos[sigla]
        print(f"Elemento: {elemento['nome']}")
        print(f"Número Atômico: {elemento['numero_atomico']}")
        print(f"Massa: {elemento['massa']}")
        break
    else:
        print("Elemento não encontrado")
