letra = input("Digite uma letra do alfabeto: ").lower()

if letra == 'a':
    print("Abacaxi")
elif letra == 'b':
    print("Bola")
elif letra == 'c':
    print("Cachorro")
elif letra == 'd':
    print("Dado")
elif letra == 'e':
    print("Elefante")
elif letra == 'f':
    print("Foca")
elif letra == 'g':
    print("Gato")
elif letra == 'h':
    print("Hóquei")
elif letra == 'i':
    print("Igreja")
elif letra == 'j':
    print("Jacaré")
elif letra == 'k':
    print("Koala")
elif letra == 'l':
    print("Leão")
elif letra == 'm':
    print("Macaco")
elif letra == 'n':
    print("Navio")
elif letra == 'o':
    print("Ovelha")
elif letra == 'p':
    print("Pato")
elif letra == 'q':
    print("Queijo")
elif letra == 'r':
    print("Rato")
elif letra == 's':
    print("Sapo")
elif letra == 't':
    print("Tigre")
elif letra == 'u':
    print("Urso")
elif letra == 'v':
    print("Vaca")
elif letra == 'w':
    print("Wolverine")
elif letra == 'x':
    print("Xícara")
elif letra == 'y':
    print("Yogurte")
elif letra == 'z':
    print("Zebra")
else:
    print("Letra inválida, por favor, insira uma letra do A ao Z.")
