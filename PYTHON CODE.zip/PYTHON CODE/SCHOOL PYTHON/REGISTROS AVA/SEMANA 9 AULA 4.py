from time import sleep
from random import randint
número = randint(1,100)
tentativas = 0

print("JOGO DE ADIVINHAÇÃO")
print("TENTE ADIVINHAR UM NÚMERO DE 1 A 100")

while True:
    try:
        palpite = int(input("\nDigite seu palpite: "))
    except ValueError:
        print("\nResposta inválida.\nPor favor digite apenas números\n")
        continue
    
    tentativas += 1
    
    if palpite > número:
        print("\nSeu palpite é maior que o número")
    elif palpite < número:
        print("\nSeu palpite é menor que o número")
    else:
        print(f"Você acertou em {tentativas} tentativas!")
        sleep(1)

        parar_programa = 0
        while True:    
            x = str(input("\nDeseja jogar novamente?"))
            
            if x == "sim":
                tentativas = 0

                break
            elif x == "não":
                parar_programa += 1
            else:
                print("\nResposta não encontrada.")
                continue
        if parar_programa > 0:
            break