def caucular_deconto(quantidade_livros, valor_total, membro_clube=False):
  
  #caucla o desconto, incluido o desconto para membros do clube
  
  if quantidade_livros >= 10:
    desconto = 0.5
  
  elif quantidade_livros < 10 and quantidade_livros >= 5:
    desconto = 0.3
  
  elif quantidade_livros < 5 and quantidade_livros >= 2:
    desconto = 0.2
  
  else:
    desconto = 0
  
  if membro_clube:
    desconto += 0.05 # Adiciona 5% de desconto para membros do clube
  
  valor_com_desconto = valor_total * (1 - desconto)
  return valor_com_desconto

#exemplo de uso com membro do clube

valor_total = 100
quantidade_livros = 5
valor_com_desconto = caucular_deconto(quantidade_livros, valor_total, membro_clube=True)
print(f"valor total com desconto para membros do clube: R${valor_com_desconto:.2f}")

#exemplo de uso sem membro do clube
valor_total = 100
quantidade_livros = 5
valor_com_desconto = caucular_deconto(quantidade_livros, valor_total)
