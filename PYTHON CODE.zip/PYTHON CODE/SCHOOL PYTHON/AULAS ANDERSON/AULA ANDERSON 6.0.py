# AULA PRÁTICA; ATIVIDADE 2

saldo = 0
saldo += int(input("Digite o saldo inicial: "))

while True:
    print("\nMENU:")
    print("1 - Saldo")
    print("2 - Deposito")
    print("3 - Saque")
    print("4 - Transferência")
    print("5 - sair")

    opção = int(input(">"))

    if opção == 1:
        print(f"Seu saldo é: {saldo[0]}")
    
    elif opção == 2:

        valor = int(input("Digite o valor do depósito: "))
        saldo[0] += valor
        print(f"Seu saldo agora é: {saldo[0]}")

    elif opção == 3:

        valor = int(input("Digite o valor do saque: "))

        if valor > saldo[0]:
            print("Saldo insuficiente")

        else:
            saldo[0] -= valor
            print(f"Seu saldo agora é: {saldo[0]}")

    elif opção == 4:

        valor = int(input("Digite o valor da transferência: "))

        if valor > saldo[0]:
            print("Saldo insuficiente")

        else:
            print("Digite os dados do remetente:\n\n")

            input("Nome completo: ")
            input("Conta: ")
            input("Agência: ")
            input("CPF: ")

            saldo[0] -= valor

            print(f"Seu saldo agora é: {saldo[0]}")

    elif opção == 5:

        print("Obrigado por usar nosso sistema, volte sempre")
        break

    else:
        print("Opção inválida, tente novamente")