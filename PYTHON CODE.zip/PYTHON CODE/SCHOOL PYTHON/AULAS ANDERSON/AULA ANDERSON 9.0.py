import sys

print("BEM VINDO A SORVETERIA!\n")

# Cardápio com os preços
sabores = {
    "1": ("Morango", 5.00),
    "2": ("Chocolate", 6.00),
    "3": ("Baunilha", 4.50),
    "4": ("uva", 5.50),
    "5": ("kiwi", 4.00),
    "6": ("pera", 3.50)
}

total = 0.0

while True:
    print("\nCardápio:")
    print("1 - Morango - R$ 5.00")
    print("2 - Chocolate - R$ 6.00")
    print("3 - Baunilha - R$ 4.50")
    print("4 - uva - R$ 5.50")
    print("5 - kiwi - R$ 4.00")
    print("6 - pera -R$ 3.50")
    print("\nG - Finalizar pedido")
    


    escolha = input("\nDigite o número do sabor desejado: ").upper

    if escolha == '1':
            print(f"\nPedido finalizado!\nTotal a pagar: R$ {total:.2f}")
            break
    elif escolha in sabores:
            sabor, preco = sabores[escolha]
            total += preco
            print(f"{sabor} adicionado ao carrinho!\nPor enquanto: R$ {total:.2f}")
    else:
            print("Opção inválida!\nPor favor, escolha uma opção do cardápio.")
    


while True:
    
    print("Você deseja comer no local ou te entregar?\n\n")
    sla = input("1 - Comer no local\n2 - Me entregar\n\n> ")
        
    if sla == "1":
        print("seu produto já foi embalado")
        break

    elif sla == "2":
        input("Digite seu cep: ")
        print("será cobrado uma taxa de R$ 3.00")
        print("seu pedido será entregue em menos de 10 minutos!")
        total += 3
        break

    else: 
        print("Digite 1 ou 2")

while True:
    resposta = int(input("qual será a forma de pagamento?\n\n1 - débito\n2 - crédito\n3 - pix\n\n> "))

    if resposta == 1:
        print("aproxime ou insira")
        sys.exit(0)
            

    elif resposta == 2:
        print("aproxime ou insira")
        sys.exit(0)
            

    elif resposta == 3:
        print("a chave pix é:\n(11) 9 5692 - 2837")
        sys.exit(0)

    else:
        print("por favor digite um número de 1 a 3")
        continue
