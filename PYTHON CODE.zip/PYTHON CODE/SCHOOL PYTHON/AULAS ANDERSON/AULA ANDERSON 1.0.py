def aplicar_desconto(valor_original, quantidade, eh_socio=False,
desconto_socio=0.10, descontos_quantidade=None):
    """
    Aplica descontos com base na quantidade e na associação do cliente.
    Args:
        valor_original (float): O valor total original da compra.
        quantidade (int): A quantidade de itens comprados.
        eh_socio (bool, optional): Indica se o cliente é sócio. Defaults to False.
        desconto_socio (float, optional): Percentual de desconto para sócios (ex: 0.10
        para 10%). Defaults to 0.10.
        descontos_quantidade (dict, optional): Dicionário com faixas de quantidade
        como chaves e percentuais de desconto como valores (ex: {5: 0.05, 10: 0.10}).
        Defaults to None (sem desconto por quantidade).
    Returns:
        float: O valor final da compra após a aplicação dos descontos.
    """
    desconto_total = 0.0
    # Aplica desconto para sócios
    if eh_socio:
        desconto_total += desconto_socio
    # Aplica desconto por quantidade
    if descontos_quantidade:
        for qtd_limite, desconto_qtd in sorted(descontos_quantidade.items()):
            if quantidade >= qtd_limite:
                desconto_total += desconto_qtd
    # Garante que o desconto não exceda 100%
    desconto_total = min(desconto_total, 1.0)
    valor_final = valor_original * (1 - desconto_total)
    return valor_final

def obter_detalhes_desconto():
    """Obtém do usuário as regras de desconto por quantidade."""
    descontos = {}
    print("\n--- Configuração de Desconto por Quantidade ---")
    print("Digite as faixas de quantidade e seus respectivos descontos percentuais.")
