def adicionar_item(lista):
    item = input("Digite o nome do item para adicionar: ").strip()
    lista.append(item)
    print(f"{item} foi adicionado à lista.")

def remover_item(lista):
    while True:   
        print(f"\n{lista}\n")
        item = input("Digite o nome do item para remover: ").strip()
        if item in lista:
            lista.remove(item)
            print(f"{item} foi removido da lista.")
            break
        else:
            print(f"{item} não está na lista.")
            sair = input("\nDigite 1 para voltar ao menu\n")
            if sair == "1":
                break  # volta para o menu

def exibir_lista(lista):
    print("\nItens na lista:")
    for item in lista:
        print(f"- {item}")
    input("\nPressione Enter para voltar ao menu...")

def buscar_item(lista):
    while True:
        item = input("Digite o nome do item para buscar: ").strip()
        if item in lista:
            print(f"'{item}' está na lista.")
            break
        else:
            print(f"'{item}' não foi encontrado na lista.")
            continuar = input("Digite 1 para tentar novamente ou Enter para voltar ao menu: ")
            if continuar != "1":
                break

def menu():
    lista_compras = []
    while True:
        print("\nMenu:")
        print("1. Adicionar item à lista")
        print("2. Remover item da lista")
        print("3. Exibir todos os itens da lista")
        print("4. Buscar um item na lista")
        print("5. Sair")
        opcao = input("Escolha uma opção (1-5): ")

        if opcao == "1":
            adicionar_item(lista_compras)
        elif opcao == "2":
            remover_item(lista_compras)
        elif opcao == "3":
            exibir_lista(lista_compras)
        elif opcao == "4":
            buscar_item(lista_compras)
        elif opcao == "5":
            print("Saindo do programa...")
            break
        else:
            print("Opção inválida. Tente novamente.")

# Executar o menu
menu()
