# EXEMPLO: CANDIDATO A PREFEITO

numero_candidato = int(input("Digite o número do candidato (1/2): "))

if numero_candidato == 1:
    print("João, partido A, Vice: Maria")

elif numero_candidato == 2:
    print("Pedro, partido B, Vice: Ana")

else:
    print("Candidato não encontrado.")