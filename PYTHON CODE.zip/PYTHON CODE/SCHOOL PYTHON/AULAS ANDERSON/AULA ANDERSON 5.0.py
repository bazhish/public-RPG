# AULA PRÁTICA; ATIVIDADE 1

idade = int(input("Digite a idade do candidato: "))

if idade >= 18:
    print("candidato apto a candidatura")

else:
    print("candidato não apto a candidatura")