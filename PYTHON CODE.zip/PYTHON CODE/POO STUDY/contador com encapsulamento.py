class Contador:
    def __init__(self):
        self.__valor = 0  # Atributo privado

    def incrementar(self):
        self.__valor += 1  # Aumenta +1

    def decrementar(self):
        self.__valor -= 1  # Diminui -1

    def get_valor(self):
        return self.__valor  # Retorna o valor atual

contador = Contador()

contador.incrementar()  # valor = 1
contador.incrementar()  # valor = 2
print(contador.get_valor())  # Deve mostrar 2

contador.decrementar()  # valor = 1
print(contador.get_valor())  # Deve mostrar 1
