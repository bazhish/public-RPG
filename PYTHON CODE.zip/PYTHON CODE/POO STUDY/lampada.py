class Lampada:
    def __init__(self):        
        self.estado = False  # Começa desligada

    def alterar_estado(self): 
            tecla = input('Use a tecla "G" para ligar ou desligar: ').upper()

            if tecla == "G":
                self.estado = not self.estado
                return "Ligada" if self.estado else "Desligada"
            else:
                return "Tecla inválida"
  
# Criar o objeto
lampada = Lampada()

# Testar
print(lampada.alterar_estado())  # Você digita G → mostra "Ligada"
print(lampada.alterar_estado())  # Você digita G → mostra "Desligada"
