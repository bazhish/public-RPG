class Usuario:
    def __init__(self, nome, senha):
        self.__nome = nome
        self.__senha = senha

    def alterar_senha(self, nova_senha):
        if len(nova_senha) >= 8:
            self.__senha = nova_senha
            print("Senha alterada com sucesso.")
        else:
            print("Senha muito curta. Mínimo de 8 caracteres.")

# Exemplo de uso
usuario = Usuario("joao123", "senha123")
usuario.alterar_senha("novaSenha123")
