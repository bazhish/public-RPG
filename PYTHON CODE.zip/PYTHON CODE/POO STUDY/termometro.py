class Termometro:
    def __init__(self, temperatura=0):
        self.__temperatura_celsius = temperatura

    def set_temperatura_fahrenheit(self, fahrenheit):
        # Converte para Celsius ao armazenar
        self.__temperatura_celsius = (fahrenheit - 32) * 5 / 9

    def get_temperatura_fahrenheit(self):
        return (self.__temperatura_celsius * 9 / 5) + 32

    def get_temperatura_celsius(self):
        return self.__temperatura_celsius

# Exemplo de uso
termometro = Termometro()
termometro.set_temperatura_fahrenheit(68)
print(termometro.get_temperatura_fahrenheit())  # Deve mostrar 68
print(termometro.get_temperatura_celsius())     # Deve mostrar 20
